package cn.wch.ch34xuartdemo;

import android.util.Log;

public class LogUtil {
    public static void d(String message){
        Log.d("UARTLibLOG",message);
    }
}
