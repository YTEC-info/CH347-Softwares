﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH341A_Programmer
{
    public class ChipId
    {
        public byte[] ID9FH = new byte[3];
        public byte[] ID90H = new byte[2];
        public byte[] IDABH = new byte[1];
        public byte[] ID15H = new byte[2];
    }
}
