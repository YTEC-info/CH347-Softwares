﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace CH341A_Programmer
{
    public partial class frmSlicer : Form
    {
        private Stream _Stream = null;

        public frmSlicer(Stream stream)
        {
            InitializeComponent();

            this._Stream = stream;
        }

        private void frmSlicer_Load(object sender, EventArgs e)
        {
            LoadComboBoxes();
        }

        private void LoadComboBoxes()
        {
            LoadPositions();
            LoadNumbers();
            LoadSizes();
        }

        private void LoadPositions()
        {
            cbx_Position.Items.Add(new ComboboxItem { Text = "First", Value = 0 });
            cbx_Position.Items.Add(new ComboboxItem { Text = "Last", Value = 1 });
            cbx_Position.SelectedIndex = 0;
        }

        private void LoadNumbers()
        {
            cbx_Number.Items.Add(new ComboboxItem { Text = "1", Value = 1 });
            cbx_Number.Items.Add(new ComboboxItem { Text = "2", Value = 2 });
            cbx_Number.Items.Add(new ComboboxItem { Text = "4", Value = 4 });
            cbx_Number.Items.Add(new ComboboxItem { Text = "8", Value = 8 });
            cbx_Number.Items.Add(new ComboboxItem { Text = "16", Value = 16 });
            cbx_Number.Items.Add(new ComboboxItem { Text = "32", Value = 32 });
            cbx_Number.Items.Add(new ComboboxItem { Text = "64", Value = 64 });
            cbx_Number.Items.Add(new ComboboxItem { Text = "128", Value = 128 });
            cbx_Number.Items.Add(new ComboboxItem { Text = "256", Value = 256 });
            cbx_Number.Items.Add(new ComboboxItem { Text = "512", Value = 512 });
            cbx_Number.SelectedIndex = 0;
        }

        private void LoadSizes()
        {
            cbx_Size.Items.Add(new ComboboxItem { Text = "B", Value = 1 });
            cbx_Size.Items.Add(new ComboboxItem { Text = "KB", Value = 1024 });
            cbx_Size.Items.Add(new ComboboxItem { Text = "MB", Value = 1048576 });
            cbx_Size.SelectedIndex = 0;
        }

        private void Slice()
        {
            if (_Stream == null)
            {
                MessageBox.Show("Please read a chip or load a data file before you can slice it.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (rdo_Position.Checked)
                {
                    int position = cbx_Position.SelectedIndex;
                    int number = int.Parse(cbx_Number.SelectedItem.ToString());
                    ComboboxItem cbi = (ComboboxItem)(cbx_Size.SelectedItem);
                    int size = int.Parse(cbi.Value.ToString());

                    if (number * size > _Stream.Length)
                    {
                        MessageBox.Show("Sliced file cannot be bigger than the original.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string name = saveFileDialog.FileName;

                        FileStream fs = new FileStream(name, FileMode.Create);

                        _Stream.Position = position == 0 ? 0 : _Stream.Length - number * size;
                        byte[] buffer = new byte[size];
                        for (int i = 0; i < number; ++i)
                        {
                            int bytesRead = _Stream.Read(buffer, 0, size);
                            fs.Write(buffer, 0, size);
                        }

                        fs.Close();
                        fs.Dispose();
                    }
                }
                else if (rdo_Range.Checked)
                {
                    int from = Convert.ToInt32(tbx_From.Text, 16);
                    int to = Convert.ToInt32(tbx_To.Text, 16);

                    if (from > _Stream.Length || to > _Stream.Length || from > to)
                    {
                        MessageBox.Show("The range you have inputed are out of range.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string name = saveFileDialog.FileName;

                        FileStream fs = new FileStream(name, FileMode.Create);

                        _Stream.Position = from;
                        byte[] buffer = new byte[to - from + 1];
                        _Stream.Read(buffer, 0, buffer.Length);
                        fs.Write(buffer, 0, buffer.Length);

                        fs.Close();
                        fs.Dispose();
                    }
                }

                MessageBox.Show("The sliced file has been created successfully.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Slice_Click(object sender, EventArgs e)
        {
            Slice();
        }
    }
}
