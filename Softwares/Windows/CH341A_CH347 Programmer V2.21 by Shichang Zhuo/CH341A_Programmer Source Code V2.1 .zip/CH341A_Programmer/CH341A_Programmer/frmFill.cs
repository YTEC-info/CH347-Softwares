﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Be.Windows.Forms;

namespace CH341A_Programmer
{
    public partial class frmFill : Form
    {
        private HexBox _MainWindowHexBox = null;

        public frmFill(ref HexBox hexBox)
        {
            InitializeComponent();
            _MainWindowHexBox = hexBox;
        }

        private void frmFill_Load(object sender, EventArgs e)
        {

        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            byte fillByte = Convert.ToByte(tbx_Fill.Text, 16);

            DynamicFileByteProvider provider = (DynamicFileByteProvider)_MainWindowHexBox.ByteProvider;

            for (long i = 0; i < provider.GetStream().Length; ++i)
                provider.WriteByte(i, fillByte);

            _MainWindowHexBox.Refresh();

            this.Close();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
