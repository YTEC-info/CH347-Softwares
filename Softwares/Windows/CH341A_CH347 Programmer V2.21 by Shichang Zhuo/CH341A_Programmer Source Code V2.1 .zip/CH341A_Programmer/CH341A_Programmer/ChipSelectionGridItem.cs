﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH341A_Programmer
{
    public class ChipSelectionGridItem
    {
        public string Type { get; set; }
        public string Manufacturer { get; set; }
        public string Name { get; set; }

        public ChipSelectionGridItem(string type, string manufacturer, string name)
        {
            this.Type = type;
            this.Manufacturer = manufacturer;
            this.Name = name;
        }
    }
}
