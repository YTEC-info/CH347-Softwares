﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CH341A_Programmer
{
    public partial class frmChipSelection : Form
    {
        private ChipSettings _ChipSettings = null;

        private frmMain _MainFrom = null;

        public frmChipSelection(ChipSettings chipSettings, frmMain frm)
        {
            InitializeComponent();

            _ChipSettings = chipSettings;
            _MainFrom = frm;
        }

        private void SerchChips(string text)
        {
            dgv_Result.DataSource = null;

            dgv_Result.DataSource = _ChipSettings.GetGridItemsByKeywords(text);

            for (int i = 0; i < dgv_Result.ColumnCount; ++i)
            {
                dgv_Result.Columns[i].AutoSizeMode = i < dgv_Result.ColumnCount - 1 ? DataGridViewAutoSizeColumnMode.AllCells : DataGridViewAutoSizeColumnMode.Fill;
            }

            dgv_Result.Refresh();
        }

        private void SelectChip()
        {
            if (dgv_Result.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgv_Result.SelectedRows[0];

                string chipType = row.Cells[0].Value.ToString();
                string chipManufacturer = row.Cells[1].Value.ToString();
                string chipName = row.Cells[2].Value.ToString();

                Chip chip = _ChipSettings.GetChip(chipType, chipManufacturer, chipName);

                _MainFrom.SetChip(chip);

                this.Close();
                this.Dispose();
            }
        }

        private void frmChipSelection_Load(object sender, EventArgs e)
        {
            btn_Select.Enabled = false;

            SerchChips("");
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void tbx_Find_TextChanged(object sender, EventArgs e)
        {
            SerchChips(tbx_Find.Text);
        }

        private void dgv_Result_SelectionChanged(object sender, EventArgs e)
        {
            DataGridView dgv = sender as DataGridView;

            if (dgv != null && dgv.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgv.SelectedRows[0];
                if (row != null)
                {
                    btn_Select.Enabled = true;
                }
                else
                {
                    btn_Select.Enabled = false;
                }
            }
            else
            {
                btn_Select.Enabled = false;
            }
        }

        private void btn_Select_Click(object sender, EventArgs e)
        {
            SelectChip();
        }

        private void dgv_Result_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            SelectChip();
        }
    }
}
