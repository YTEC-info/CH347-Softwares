﻿namespace CH341A_Programmer
{
    partial class frmGoTo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbx_Position = new System.Windows.Forms.GroupBox();
            this.tbx_HexLocation = new System.Windows.Forms.TextBox();
            this.lbl_HexLocation = new System.Windows.Forms.Label();
            this.nud_ByteNumber = new System.Windows.Forms.NumericUpDown();
            this.lbl_ByteNumber = new System.Windows.Forms.Label();
            this.gbx_Actions = new System.Windows.Forms.GroupBox();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.gbx_Position.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ByteNumber)).BeginInit();
            this.gbx_Actions.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbx_Position
            // 
            this.gbx_Position.Controls.Add(this.tbx_HexLocation);
            this.gbx_Position.Controls.Add(this.lbl_HexLocation);
            this.gbx_Position.Controls.Add(this.nud_ByteNumber);
            this.gbx_Position.Controls.Add(this.lbl_ByteNumber);
            this.gbx_Position.Location = new System.Drawing.Point(12, 12);
            this.gbx_Position.Name = "gbx_Position";
            this.gbx_Position.Size = new System.Drawing.Size(285, 103);
            this.gbx_Position.TabIndex = 0;
            this.gbx_Position.TabStop = false;
            this.gbx_Position.Text = "Go To Position";
            // 
            // tbx_HexLocation
            // 
            this.tbx_HexLocation.Location = new System.Drawing.Point(95, 62);
            this.tbx_HexLocation.Name = "tbx_HexLocation";
            this.tbx_HexLocation.Size = new System.Drawing.Size(163, 20);
            this.tbx_HexLocation.TabIndex = 1;
            this.tbx_HexLocation.TextChanged += new System.EventHandler(this.tbx_HexLocation_TextChanged);
            // 
            // lbl_HexLocation
            // 
            this.lbl_HexLocation.AutoSize = true;
            this.lbl_HexLocation.Location = new System.Drawing.Point(18, 65);
            this.lbl_HexLocation.Name = "lbl_HexLocation";
            this.lbl_HexLocation.Size = new System.Drawing.Size(73, 13);
            this.lbl_HexLocation.TabIndex = 2;
            this.lbl_HexLocation.Text = "Hex Location:";
            // 
            // nud_ByteNumber
            // 
            this.nud_ByteNumber.Location = new System.Drawing.Point(95, 27);
            this.nud_ByteNumber.Name = "nud_ByteNumber";
            this.nud_ByteNumber.Size = new System.Drawing.Size(163, 20);
            this.nud_ByteNumber.TabIndex = 0;
            this.nud_ByteNumber.ValueChanged += new System.EventHandler(this.nud_ByteNumber_ValueChanged);
            // 
            // lbl_ByteNumber
            // 
            this.lbl_ByteNumber.AutoSize = true;
            this.lbl_ByteNumber.Location = new System.Drawing.Point(18, 29);
            this.lbl_ByteNumber.Name = "lbl_ByteNumber";
            this.lbl_ByteNumber.Size = new System.Drawing.Size(71, 13);
            this.lbl_ByteNumber.TabIndex = 0;
            this.lbl_ByteNumber.Text = "Byte Number:";
            // 
            // gbx_Actions
            // 
            this.gbx_Actions.Controls.Add(this.btn_OK);
            this.gbx_Actions.Controls.Add(this.btn_Cancel);
            this.gbx_Actions.Location = new System.Drawing.Point(12, 121);
            this.gbx_Actions.Name = "gbx_Actions";
            this.gbx_Actions.Size = new System.Drawing.Size(285, 54);
            this.gbx_Actions.TabIndex = 1;
            this.gbx_Actions.TabStop = false;
            this.gbx_Actions.Text = "Actions";
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(95, 19);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 2;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.Location = new System.Drawing.Point(183, 19);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 3;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // frmGoTo
            // 
            this.AcceptButton = this.btn_OK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_Cancel;
            this.ClientSize = new System.Drawing.Size(311, 192);
            this.Controls.Add(this.gbx_Actions);
            this.Controls.Add(this.gbx_Position);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmGoTo";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Go To";
            this.Activated += new System.EventHandler(this.frmGoTo_Activated);
            this.Load += new System.EventHandler(this.frmGoTo_Load);
            this.gbx_Position.ResumeLayout(false);
            this.gbx_Position.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ByteNumber)).EndInit();
            this.gbx_Actions.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbx_Position;
        private System.Windows.Forms.TextBox tbx_HexLocation;
        private System.Windows.Forms.Label lbl_HexLocation;
        private System.Windows.Forms.NumericUpDown nud_ByteNumber;
        private System.Windows.Forms.Label lbl_ByteNumber;
        private System.Windows.Forms.GroupBox gbx_Actions;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_Cancel;
    }
}