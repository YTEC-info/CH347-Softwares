﻿namespace CH341A_Programmer
{
    partial class frmSlicer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbx_Select = new System.Windows.Forms.GroupBox();
            this.tbx_To = new System.Windows.Forms.TextBox();
            this.tbx_From = new System.Windows.Forms.TextBox();
            this.lbl_To = new System.Windows.Forms.Label();
            this.lbl_From = new System.Windows.Forms.Label();
            this.cbx_Size = new System.Windows.Forms.ComboBox();
            this.cbx_Number = new System.Windows.Forms.ComboBox();
            this.cbx_Position = new System.Windows.Forms.ComboBox();
            this.rdo_Range = new System.Windows.Forms.RadioButton();
            this.rdo_Position = new System.Windows.Forms.RadioButton();
            this.gbx_Actions = new System.Windows.Forms.GroupBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Slice = new System.Windows.Forms.Button();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.gbx_Select.SuspendLayout();
            this.gbx_Actions.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbx_Select
            // 
            this.gbx_Select.Controls.Add(this.tbx_To);
            this.gbx_Select.Controls.Add(this.tbx_From);
            this.gbx_Select.Controls.Add(this.lbl_To);
            this.gbx_Select.Controls.Add(this.lbl_From);
            this.gbx_Select.Controls.Add(this.cbx_Size);
            this.gbx_Select.Controls.Add(this.cbx_Number);
            this.gbx_Select.Controls.Add(this.cbx_Position);
            this.gbx_Select.Controls.Add(this.rdo_Range);
            this.gbx_Select.Controls.Add(this.rdo_Position);
            this.gbx_Select.Location = new System.Drawing.Point(12, 12);
            this.gbx_Select.Name = "gbx_Select";
            this.gbx_Select.Size = new System.Drawing.Size(328, 147);
            this.gbx_Select.TabIndex = 0;
            this.gbx_Select.TabStop = false;
            this.gbx_Select.Text = "Select";
            // 
            // tbx_To
            // 
            this.tbx_To.Location = new System.Drawing.Point(164, 105);
            this.tbx_To.Name = "tbx_To";
            this.tbx_To.Size = new System.Drawing.Size(141, 20);
            this.tbx_To.TabIndex = 8;
            // 
            // tbx_From
            // 
            this.tbx_From.Location = new System.Drawing.Point(164, 74);
            this.tbx_From.Name = "tbx_From";
            this.tbx_From.Size = new System.Drawing.Size(141, 20);
            this.tbx_From.TabIndex = 7;
            // 
            // lbl_To
            // 
            this.lbl_To.AutoSize = true;
            this.lbl_To.Location = new System.Drawing.Point(125, 108);
            this.lbl_To.Name = "lbl_To";
            this.lbl_To.Size = new System.Drawing.Size(23, 13);
            this.lbl_To.TabIndex = 6;
            this.lbl_To.Text = "To:";
            // 
            // lbl_From
            // 
            this.lbl_From.AutoSize = true;
            this.lbl_From.Location = new System.Drawing.Point(125, 77);
            this.lbl_From.Name = "lbl_From";
            this.lbl_From.Size = new System.Drawing.Size(33, 13);
            this.lbl_From.TabIndex = 5;
            this.lbl_From.Text = "From:";
            // 
            // cbx_Size
            // 
            this.cbx_Size.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Size.FormattingEnabled = true;
            this.cbx_Size.Location = new System.Drawing.Point(250, 31);
            this.cbx_Size.Name = "cbx_Size";
            this.cbx_Size.Size = new System.Drawing.Size(55, 21);
            this.cbx_Size.TabIndex = 4;
            // 
            // cbx_Number
            // 
            this.cbx_Number.FormattingEnabled = true;
            this.cbx_Number.Location = new System.Drawing.Point(181, 31);
            this.cbx_Number.Name = "cbx_Number";
            this.cbx_Number.Size = new System.Drawing.Size(63, 21);
            this.cbx_Number.TabIndex = 3;
            // 
            // cbx_Position
            // 
            this.cbx_Position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Position.FormattingEnabled = true;
            this.cbx_Position.Location = new System.Drawing.Point(86, 30);
            this.cbx_Position.Name = "cbx_Position";
            this.cbx_Position.Size = new System.Drawing.Size(89, 21);
            this.cbx_Position.TabIndex = 2;
            // 
            // rdo_Range
            // 
            this.rdo_Range.AutoSize = true;
            this.rdo_Range.Location = new System.Drawing.Point(15, 75);
            this.rdo_Range.Name = "rdo_Range";
            this.rdo_Range.Size = new System.Drawing.Size(91, 17);
            this.rdo_Range.TabIndex = 1;
            this.rdo_Range.TabStop = true;
            this.rdo_Range.Text = "Range (HEX):";
            this.rdo_Range.UseVisualStyleBackColor = true;
            // 
            // rdo_Position
            // 
            this.rdo_Position.AutoSize = true;
            this.rdo_Position.Location = new System.Drawing.Point(15, 31);
            this.rdo_Position.Name = "rdo_Position";
            this.rdo_Position.Size = new System.Drawing.Size(65, 17);
            this.rdo_Position.TabIndex = 0;
            this.rdo_Position.TabStop = true;
            this.rdo_Position.Text = "Position:";
            this.rdo_Position.UseVisualStyleBackColor = true;
            // 
            // gbx_Actions
            // 
            this.gbx_Actions.Controls.Add(this.btn_Cancel);
            this.gbx_Actions.Controls.Add(this.btn_Slice);
            this.gbx_Actions.Location = new System.Drawing.Point(12, 165);
            this.gbx_Actions.Name = "gbx_Actions";
            this.gbx_Actions.Size = new System.Drawing.Size(328, 55);
            this.gbx_Actions.TabIndex = 2;
            this.gbx_Actions.TabStop = false;
            this.gbx_Actions.Text = "Actions";
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.Location = new System.Drawing.Point(230, 19);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 10;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Slice
            // 
            this.btn_Slice.Location = new System.Drawing.Point(137, 19);
            this.btn_Slice.Name = "btn_Slice";
            this.btn_Slice.Size = new System.Drawing.Size(75, 23);
            this.btn_Slice.TabIndex = 9;
            this.btn_Slice.Text = "Slice";
            this.btn_Slice.UseVisualStyleBackColor = true;
            this.btn_Slice.Click += new System.EventHandler(this.btn_Slice_Click);
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "Binary files (*.bin) | *.bin|All files (*.*) | *.*";
            // 
            // frmSlicer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 234);
            this.Controls.Add(this.gbx_Actions);
            this.Controls.Add(this.gbx_Select);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSlicer";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "File Slicer";
            this.Load += new System.EventHandler(this.frmSlicer_Load);
            this.gbx_Select.ResumeLayout(false);
            this.gbx_Select.PerformLayout();
            this.gbx_Actions.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbx_Select;
        private System.Windows.Forms.TextBox tbx_To;
        private System.Windows.Forms.TextBox tbx_From;
        private System.Windows.Forms.Label lbl_To;
        private System.Windows.Forms.Label lbl_From;
        private System.Windows.Forms.ComboBox cbx_Size;
        private System.Windows.Forms.ComboBox cbx_Number;
        private System.Windows.Forms.ComboBox cbx_Position;
        private System.Windows.Forms.RadioButton rdo_Range;
        private System.Windows.Forms.RadioButton rdo_Position;
        private System.Windows.Forms.GroupBox gbx_Actions;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Slice;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}