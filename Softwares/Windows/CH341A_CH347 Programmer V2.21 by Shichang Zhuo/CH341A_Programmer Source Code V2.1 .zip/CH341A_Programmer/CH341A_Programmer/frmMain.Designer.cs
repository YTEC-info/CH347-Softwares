﻿namespace CH341A_Programmer
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.msp_Programmer = new System.Windows.Forms.MenuStrip();
            this.fileFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.copyHexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteHexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.findToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findNextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goToToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectICToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.eraseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.readToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verifyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.blankCheckToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fillChipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileSlicerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileMergerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programmerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cH347ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.i2CSpeedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.i2c3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.i2c2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.i2c1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.i2c0ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spi0SpeedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spi0ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spi1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spi2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spi3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spi4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spi5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spi6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spi7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsp_Programmer = new System.Windows.Forms.ToolStrip();
            this.btn_Open = new System.Windows.Forms.ToolStripButton();
            this.btn_Save = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_Read = new System.Windows.Forms.ToolStripButton();
            this.btn_Erase = new System.Windows.Forms.ToolStripButton();
            this.btn_Program = new System.Windows.Forms.ToolStripButton();
            this.btn_Verify = new System.Windows.Forms.ToolStripButton();
            this.btn_Auto = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_Blank = new System.Windows.Forms.ToolStripButton();
            this.btn_Fill = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_About = new System.Windows.Forms.ToolStripButton();
            this.gbx_Chip = new System.Windows.Forms.GroupBox();
            this.btn_ChipSearch = new System.Windows.Forms.Button();
            this.btn_Detect = new System.Windows.Forms.Button();
            this.cbx_Part = new System.Windows.Forms.ComboBox();
            this.lbl_PartNumber = new System.Windows.Forms.Label();
            this.cbx_Manufacturer = new System.Windows.Forms.ComboBox();
            this.lbl_Manufacturer = new System.Windows.Forms.Label();
            this.cbx_Type = new System.Windows.Forms.ComboBox();
            this.lbl_Type = new System.Windows.Forms.Label();
            this.gbx_Info = new System.Windows.Forms.GroupBox();
            this.cbx_Command = new System.Windows.Forms.ComboBox();
            this.lbl_Command = new System.Windows.Forms.Label();
            this.cbx_PageSize = new System.Windows.Forms.ComboBox();
            this.lbl_PageSize = new System.Windows.Forms.Label();
            this.cbx_ChipSize = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.sts_Status = new System.Windows.Forms.StatusStrip();
            this.lbl_Status = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbl_FileSize = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbl_BitStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbl_Operations = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbl_Empty = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbl_ConnectionStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.gbx_FontSize = new System.Windows.Forms.GroupBox();
            this.btn_FontSizeMinus = new System.Windows.Forms.Button();
            this.btn_FontSizePlus = new System.Windows.Forms.Button();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.pbr_Progress = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.hbx_Edit = new Be.Windows.Forms.HexBox();
            this.msp_Programmer.SuspendLayout();
            this.tsp_Programmer.SuspendLayout();
            this.gbx_Chip.SuspendLayout();
            this.gbx_Info.SuspendLayout();
            this.sts_Status.SuspendLayout();
            this.gbx_FontSize.SuspendLayout();
            this.SuspendLayout();
            // 
            // msp_Programmer
            // 
            this.msp_Programmer.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.msp_Programmer.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileFToolStripMenuItem,
            this.toolStripMenuItem3,
            this.selectICToolStripMenuItem,
            this.operationsToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.programmerToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.msp_Programmer.Location = new System.Drawing.Point(0, 0);
            this.msp_Programmer.Name = "msp_Programmer";
            this.msp_Programmer.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.msp_Programmer.Size = new System.Drawing.Size(811, 24);
            this.msp_Programmer.TabIndex = 0;
            this.msp_Programmer.Text = "menuStrip1";
            // 
            // fileFToolStripMenuItem
            // 
            this.fileFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileFToolStripMenuItem.Name = "fileFToolStripMenuItem";
            this.fileFToolStripMenuItem.Size = new System.Drawing.Size(37, 22);
            this.fileFToolStripMenuItem.Text = "&File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Image = global::CH341A_Programmer.images.openHS;
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.openToolStripMenuItem.Text = "&Open File";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Image = global::CH341A_Programmer.images.saveHS;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.saveToolStripMenuItem.Text = "&Save File";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(164, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.toolStripMenuItem4,
            this.copyHexToolStripMenuItem,
            this.pasteHexToolStripMenuItem,
            this.toolStripMenuItem5,
            this.findToolStripMenuItem,
            this.findNextToolStripMenuItem,
            this.goToToolStripMenuItem,
            this.selectAllToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(39, 22);
            this.toolStripMenuItem3.Text = "&Edit";
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Image = global::CH341A_Programmer.images.CutHS;
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.cutToolStripMenuItem.Text = "Cu&t";
            this.cutToolStripMenuItem.Click += new System.EventHandler(this.cutToolStripMenuItem_Click);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Image = global::CH341A_Programmer.images.CopyHS;
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.copyToolStripMenuItem.Text = "&Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Image = global::CH341A_Programmer.images.PasteHS;
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.pasteToolStripMenuItem.Text = "&Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(197, 6);
            // 
            // copyHexToolStripMenuItem
            // 
            this.copyHexToolStripMenuItem.Name = "copyHexToolStripMenuItem";
            this.copyHexToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.C)));
            this.copyHexToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.copyHexToolStripMenuItem.Text = "Copy Hex";
            this.copyHexToolStripMenuItem.Click += new System.EventHandler(this.copyHexToolStripMenuItem_Click);
            // 
            // pasteHexToolStripMenuItem
            // 
            this.pasteHexToolStripMenuItem.Name = "pasteHexToolStripMenuItem";
            this.pasteHexToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.V)));
            this.pasteHexToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.pasteHexToolStripMenuItem.Text = "Paste Hex";
            this.pasteHexToolStripMenuItem.Click += new System.EventHandler(this.pasteHexToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(197, 6);
            // 
            // findToolStripMenuItem
            // 
            this.findToolStripMenuItem.Image = global::CH341A_Programmer.images.FindHS;
            this.findToolStripMenuItem.Name = "findToolStripMenuItem";
            this.findToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.findToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.findToolStripMenuItem.Text = "Find";
            this.findToolStripMenuItem.Click += new System.EventHandler(this.findToolStripMenuItem_Click);
            // 
            // findNextToolStripMenuItem
            // 
            this.findNextToolStripMenuItem.Image = global::CH341A_Programmer.images.FindNextHS;
            this.findNextToolStripMenuItem.Name = "findNextToolStripMenuItem";
            this.findNextToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.findNextToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.findNextToolStripMenuItem.Text = "Find Next";
            this.findNextToolStripMenuItem.Click += new System.EventHandler(this.findNextToolStripMenuItem_Click);
            // 
            // goToToolStripMenuItem
            // 
            this.goToToolStripMenuItem.Name = "goToToolStripMenuItem";
            this.goToToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.goToToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.goToToolStripMenuItem.Text = "Go To";
            this.goToToolStripMenuItem.Click += new System.EventHandler(this.goToToolStripMenuItem_Click);
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.selectAllToolStripMenuItem.Text = "Select &All";
            this.selectAllToolStripMenuItem.Click += new System.EventHandler(this.selectAllToolStripMenuItem_Click);
            // 
            // selectICToolStripMenuItem
            // 
            this.selectICToolStripMenuItem.Name = "selectICToolStripMenuItem";
            this.selectICToolStripMenuItem.Size = new System.Drawing.Size(64, 22);
            this.selectICToolStripMenuItem.Text = "&Select IC";
            this.selectICToolStripMenuItem.Click += new System.EventHandler(this.selectICToolStripMenuItem_Click);
            // 
            // operationsToolStripMenuItem
            // 
            this.operationsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.autoToolStripMenuItem,
            this.toolStripMenuItem2,
            this.eraseToolStripMenuItem,
            this.programToolStripMenuItem,
            this.readToolStripMenuItem,
            this.verifyToolStripMenuItem,
            this.toolStripSeparator5,
            this.blankCheckToolStripMenuItem,
            this.fillChipToolStripMenuItem});
            this.operationsToolStripMenuItem.Name = "operationsToolStripMenuItem";
            this.operationsToolStripMenuItem.Size = new System.Drawing.Size(77, 22);
            this.operationsToolStripMenuItem.Text = "&Operations";
            // 
            // autoToolStripMenuItem
            // 
            this.autoToolStripMenuItem.Name = "autoToolStripMenuItem";
            this.autoToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.autoToolStripMenuItem.Text = "&Automatic";
            this.autoToolStripMenuItem.Click += new System.EventHandler(this.autoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(145, 6);
            // 
            // eraseToolStripMenuItem
            // 
            this.eraseToolStripMenuItem.Name = "eraseToolStripMenuItem";
            this.eraseToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.eraseToolStripMenuItem.Text = "&Erase Chip";
            this.eraseToolStripMenuItem.Click += new System.EventHandler(this.eraseToolStripMenuItem_Click);
            // 
            // programToolStripMenuItem
            // 
            this.programToolStripMenuItem.Name = "programToolStripMenuItem";
            this.programToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.programToolStripMenuItem.Text = "&Program Chip";
            this.programToolStripMenuItem.Click += new System.EventHandler(this.programToolStripMenuItem_Click);
            // 
            // readToolStripMenuItem
            // 
            this.readToolStripMenuItem.Name = "readToolStripMenuItem";
            this.readToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.readToolStripMenuItem.Text = "&Read Chip";
            this.readToolStripMenuItem.Click += new System.EventHandler(this.readToolStripMenuItem_Click);
            // 
            // verifyToolStripMenuItem
            // 
            this.verifyToolStripMenuItem.Name = "verifyToolStripMenuItem";
            this.verifyToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.verifyToolStripMenuItem.Text = "&Verify Chip";
            this.verifyToolStripMenuItem.Click += new System.EventHandler(this.verifyToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(145, 6);
            // 
            // blankCheckToolStripMenuItem
            // 
            this.blankCheckToolStripMenuItem.Name = "blankCheckToolStripMenuItem";
            this.blankCheckToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.blankCheckToolStripMenuItem.Text = "&Blank Check";
            this.blankCheckToolStripMenuItem.Click += new System.EventHandler(this.blankCheckToolStripMenuItem_Click);
            // 
            // fillChipToolStripMenuItem
            // 
            this.fillChipToolStripMenuItem.Name = "fillChipToolStripMenuItem";
            this.fillChipToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.fillChipToolStripMenuItem.Text = "&Fill Chip";
            this.fillChipToolStripMenuItem.Click += new System.EventHandler(this.fillChipToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileSlicerToolStripMenuItem,
            this.fileMergerToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(46, 22);
            this.toolsToolStripMenuItem.Text = "&Tools";
            // 
            // fileSlicerToolStripMenuItem
            // 
            this.fileSlicerToolStripMenuItem.Name = "fileSlicerToolStripMenuItem";
            this.fileSlicerToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.fileSlicerToolStripMenuItem.Text = "File &Slicer";
            this.fileSlicerToolStripMenuItem.Click += new System.EventHandler(this.fileSlicerToolStripMenuItem_Click);
            // 
            // fileMergerToolStripMenuItem
            // 
            this.fileMergerToolStripMenuItem.Name = "fileMergerToolStripMenuItem";
            this.fileMergerToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.fileMergerToolStripMenuItem.Text = "File &Merger";
            this.fileMergerToolStripMenuItem.Click += new System.EventHandler(this.fileMergerToolStripMenuItem_Click);
            // 
            // programmerToolStripMenuItem
            // 
            this.programmerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cH347ToolStripMenuItem});
            this.programmerToolStripMenuItem.Name = "programmerToolStripMenuItem";
            this.programmerToolStripMenuItem.Size = new System.Drawing.Size(86, 22);
            this.programmerToolStripMenuItem.Text = "&Programmer";
            // 
            // cH347ToolStripMenuItem
            // 
            this.cH347ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.i2CSpeedToolStripMenuItem,
            this.spi0SpeedToolStripMenuItem});
            this.cH347ToolStripMenuItem.Name = "cH347ToolStripMenuItem";
            this.cH347ToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.cH347ToolStripMenuItem.Text = "CH347";
            // 
            // i2CSpeedToolStripMenuItem
            // 
            this.i2CSpeedToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.i2c3ToolStripMenuItem,
            this.i2c2ToolStripMenuItem,
            this.i2c1ToolStripMenuItem,
            this.i2c0ToolStripMenuItem});
            this.i2CSpeedToolStripMenuItem.Name = "i2CSpeedToolStripMenuItem";
            this.i2CSpeedToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.i2CSpeedToolStripMenuItem.Text = "I2C Speed";
            // 
            // i2c3ToolStripMenuItem
            // 
            this.i2c3ToolStripMenuItem.Name = "i2c3ToolStripMenuItem";
            this.i2c3ToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.i2c3ToolStripMenuItem.Text = "750K Hz";
            this.i2c3ToolStripMenuItem.Click += new System.EventHandler(this.i2c3ToolStripMenuItem_Click);
            // 
            // i2c2ToolStripMenuItem
            // 
            this.i2c2ToolStripMenuItem.Name = "i2c2ToolStripMenuItem";
            this.i2c2ToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.i2c2ToolStripMenuItem.Text = "400K Hz";
            this.i2c2ToolStripMenuItem.Click += new System.EventHandler(this.i2c2ToolStripMenuItem_Click);
            // 
            // i2c1ToolStripMenuItem
            // 
            this.i2c1ToolStripMenuItem.Checked = true;
            this.i2c1ToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.i2c1ToolStripMenuItem.Name = "i2c1ToolStripMenuItem";
            this.i2c1ToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.i2c1ToolStripMenuItem.Text = "100K Hz";
            this.i2c1ToolStripMenuItem.Click += new System.EventHandler(this.i2c1ToolStripMenuItem_Click);
            // 
            // i2c0ToolStripMenuItem
            // 
            this.i2c0ToolStripMenuItem.Name = "i2c0ToolStripMenuItem";
            this.i2c0ToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.i2c0ToolStripMenuItem.Text = "20K Hz";
            this.i2c0ToolStripMenuItem.Click += new System.EventHandler(this.i2c0ToolStripMenuItem_Click);
            // 
            // spi0SpeedToolStripMenuItem
            // 
            this.spi0SpeedToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.spi0ToolStripMenuItem,
            this.spi1ToolStripMenuItem,
            this.spi2ToolStripMenuItem,
            this.spi3ToolStripMenuItem,
            this.spi4ToolStripMenuItem,
            this.spi5ToolStripMenuItem,
            this.spi6ToolStripMenuItem,
            this.spi7ToolStripMenuItem});
            this.spi0SpeedToolStripMenuItem.Name = "spi0SpeedToolStripMenuItem";
            this.spi0SpeedToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.spi0SpeedToolStripMenuItem.Text = "SPI Speed";
            // 
            // spi0ToolStripMenuItem
            // 
            this.spi0ToolStripMenuItem.Checked = true;
            this.spi0ToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.spi0ToolStripMenuItem.Name = "spi0ToolStripMenuItem";
            this.spi0ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.spi0ToolStripMenuItem.Text = "60M Hz";
            this.spi0ToolStripMenuItem.Click += new System.EventHandler(this.spi0ToolStripMenuItem_Click);
            // 
            // spi1ToolStripMenuItem
            // 
            this.spi1ToolStripMenuItem.Name = "spi1ToolStripMenuItem";
            this.spi1ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.spi1ToolStripMenuItem.Text = "30M Hz";
            this.spi1ToolStripMenuItem.Click += new System.EventHandler(this.spi1ToolStripMenuItem_Click);
            // 
            // spi2ToolStripMenuItem
            // 
            this.spi2ToolStripMenuItem.Name = "spi2ToolStripMenuItem";
            this.spi2ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.spi2ToolStripMenuItem.Text = "15M Hz";
            this.spi2ToolStripMenuItem.Click += new System.EventHandler(this.spi2ToolStripMenuItem_Click);
            // 
            // spi3ToolStripMenuItem
            // 
            this.spi3ToolStripMenuItem.Name = "spi3ToolStripMenuItem";
            this.spi3ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.spi3ToolStripMenuItem.Text = "7.5M Hz";
            this.spi3ToolStripMenuItem.Click += new System.EventHandler(this.spi3ToolStripMenuItem_Click);
            // 
            // spi4ToolStripMenuItem
            // 
            this.spi4ToolStripMenuItem.Name = "spi4ToolStripMenuItem";
            this.spi4ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.spi4ToolStripMenuItem.Text = "3.75M Hz";
            this.spi4ToolStripMenuItem.Click += new System.EventHandler(this.spi4ToolStripMenuItem_Click);
            // 
            // spi5ToolStripMenuItem
            // 
            this.spi5ToolStripMenuItem.Name = "spi5ToolStripMenuItem";
            this.spi5ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.spi5ToolStripMenuItem.Text = "1.875M Hz";
            this.spi5ToolStripMenuItem.Click += new System.EventHandler(this.spi5ToolStripMenuItem_Click);
            // 
            // spi6ToolStripMenuItem
            // 
            this.spi6ToolStripMenuItem.Name = "spi6ToolStripMenuItem";
            this.spi6ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.spi6ToolStripMenuItem.Text = "937.5K Hz";
            this.spi6ToolStripMenuItem.Click += new System.EventHandler(this.spi6ToolStripMenuItem_Click);
            // 
            // spi7ToolStripMenuItem
            // 
            this.spi7ToolStripMenuItem.Name = "spi7ToolStripMenuItem";
            this.spi7ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.spi7ToolStripMenuItem.Text = "468.75K Hz";
            this.spi7ToolStripMenuItem.Click += new System.EventHandler(this.spi7ToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 22);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.aboutToolStripMenuItem.Text = "&About...";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // tsp_Programmer
            // 
            this.tsp_Programmer.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.tsp_Programmer.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btn_Open,
            this.btn_Save,
            this.toolStripSeparator1,
            this.btn_Read,
            this.btn_Erase,
            this.btn_Program,
            this.btn_Verify,
            this.btn_Auto,
            this.toolStripSeparator2,
            this.btn_Blank,
            this.btn_Fill,
            this.toolStripSeparator3,
            this.btn_About});
            this.tsp_Programmer.Location = new System.Drawing.Point(0, 24);
            this.tsp_Programmer.Name = "tsp_Programmer";
            this.tsp_Programmer.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.tsp_Programmer.Size = new System.Drawing.Size(811, 54);
            this.tsp_Programmer.TabIndex = 1;
            this.tsp_Programmer.Text = "tsp_Programmer";
            // 
            // btn_Open
            // 
            this.btn_Open.Image = global::CH341A_Programmer.images.icons8_opened_folder_64;
            this.btn_Open.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Open.Name = "btn_Open";
            this.btn_Open.Size = new System.Drawing.Size(40, 51);
            this.btn_Open.Text = "Open";
            this.btn_Open.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.btn_Open.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Open.ToolTipText = "Open File";
            this.btn_Open.Click += new System.EventHandler(this.btn_Open_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Image = global::CH341A_Programmer.images.icons8_save_64;
            this.btn_Save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(36, 51);
            this.btn_Save.Text = "Save";
            this.btn_Save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Save.ToolTipText = "Save File";
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 54);
            // 
            // btn_Read
            // 
            this.btn_Read.Image = global::CH341A_Programmer.images.icons8_read_64;
            this.btn_Read.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Read.Name = "btn_Read";
            this.btn_Read.Size = new System.Drawing.Size(37, 51);
            this.btn_Read.Text = "Read";
            this.btn_Read.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Read.ToolTipText = "Read Chip To Buffer";
            this.btn_Read.Click += new System.EventHandler(this.btn_Read_Click);
            // 
            // btn_Erase
            // 
            this.btn_Erase.Image = global::CH341A_Programmer.images.icons8_eraser_64;
            this.btn_Erase.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Erase.Name = "btn_Erase";
            this.btn_Erase.Size = new System.Drawing.Size(38, 51);
            this.btn_Erase.Text = "Erase";
            this.btn_Erase.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Erase.ToolTipText = "Erase Chip";
            this.btn_Erase.Click += new System.EventHandler(this.btn_Erase_Click);
            // 
            // btn_Program
            // 
            this.btn_Program.Image = global::CH341A_Programmer.images.icons8_edit_64;
            this.btn_Program.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Program.Name = "btn_Program";
            this.btn_Program.Size = new System.Drawing.Size(57, 51);
            this.btn_Program.Text = "Program";
            this.btn_Program.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Program.ToolTipText = "Program Chip From Buffer";
            this.btn_Program.Click += new System.EventHandler(this.btn_Program_Click);
            // 
            // btn_Verify
            // 
            this.btn_Verify.Image = global::CH341A_Programmer.images.icons8_check_file_64;
            this.btn_Verify.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Verify.Name = "btn_Verify";
            this.btn_Verify.Size = new System.Drawing.Size(40, 51);
            this.btn_Verify.Text = "Verify";
            this.btn_Verify.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Verify.ToolTipText = "Verify Chip With Buffer";
            this.btn_Verify.Click += new System.EventHandler(this.btn_Verify_Click);
            // 
            // btn_Auto
            // 
            this.btn_Auto.Image = global::CH341A_Programmer.images.icons8_automatic_64;
            this.btn_Auto.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Auto.Name = "btn_Auto";
            this.btn_Auto.Size = new System.Drawing.Size(37, 51);
            this.btn_Auto.Text = "Auto";
            this.btn_Auto.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Auto.ToolTipText = "Auto Mode (Earse > Program > Verify)";
            this.btn_Auto.Click += new System.EventHandler(this.btn_Auto_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 54);
            // 
            // btn_Blank
            // 
            this.btn_Blank.Image = global::CH341A_Programmer.images.icons8_check_64;
            this.btn_Blank.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Blank.Name = "btn_Blank";
            this.btn_Blank.Size = new System.Drawing.Size(40, 51);
            this.btn_Blank.Text = "Blank";
            this.btn_Blank.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Blank.ToolTipText = "Chip Blank Check";
            this.btn_Blank.Click += new System.EventHandler(this.btn_Blank_Click);
            // 
            // btn_Fill
            // 
            this.btn_Fill.Image = global::CH341A_Programmer.images.icons8_fill_color_64;
            this.btn_Fill.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Fill.Name = "btn_Fill";
            this.btn_Fill.Size = new System.Drawing.Size(36, 51);
            this.btn_Fill.Text = "Fill";
            this.btn_Fill.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Fill.ToolTipText = "Fill Buffer With FF";
            this.btn_Fill.Click += new System.EventHandler(this.btn_Fill_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 54);
            // 
            // btn_About
            // 
            this.btn_About.Image = global::CH341A_Programmer.images.icons8_about_64;
            this.btn_About.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_About.Name = "btn_About";
            this.btn_About.Size = new System.Drawing.Size(44, 51);
            this.btn_About.Text = "About";
            this.btn_About.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_About.ToolTipText = "About This Software";
            this.btn_About.Click += new System.EventHandler(this.btn_About_Click);
            // 
            // gbx_Chip
            // 
            this.gbx_Chip.Controls.Add(this.btn_ChipSearch);
            this.gbx_Chip.Controls.Add(this.btn_Detect);
            this.gbx_Chip.Controls.Add(this.cbx_Part);
            this.gbx_Chip.Controls.Add(this.lbl_PartNumber);
            this.gbx_Chip.Controls.Add(this.cbx_Manufacturer);
            this.gbx_Chip.Controls.Add(this.lbl_Manufacturer);
            this.gbx_Chip.Controls.Add(this.cbx_Type);
            this.gbx_Chip.Controls.Add(this.lbl_Type);
            this.gbx_Chip.Location = new System.Drawing.Point(3, 81);
            this.gbx_Chip.Name = "gbx_Chip";
            this.gbx_Chip.Size = new System.Drawing.Size(805, 52);
            this.gbx_Chip.TabIndex = 2;
            this.gbx_Chip.TabStop = false;
            this.gbx_Chip.Text = "Chip Select";
            // 
            // btn_ChipSearch
            // 
            this.btn_ChipSearch.Location = new System.Drawing.Point(605, 18);
            this.btn_ChipSearch.Name = "btn_ChipSearch";
            this.btn_ChipSearch.Size = new System.Drawing.Size(75, 23);
            this.btn_ChipSearch.TabIndex = 7;
            this.btn_ChipSearch.Text = "Search";
            this.btn_ChipSearch.UseVisualStyleBackColor = true;
            this.btn_ChipSearch.Click += new System.EventHandler(this.btn_ChipSearch_Click);
            // 
            // btn_Detect
            // 
            this.btn_Detect.Location = new System.Drawing.Point(686, 18);
            this.btn_Detect.Name = "btn_Detect";
            this.btn_Detect.Size = new System.Drawing.Size(110, 23);
            this.btn_Detect.TabIndex = 6;
            this.btn_Detect.Text = "Auto Detect (25xx)";
            this.btn_Detect.UseVisualStyleBackColor = true;
            this.btn_Detect.Click += new System.EventHandler(this.btn_Detect_Click);
            // 
            // cbx_Part
            // 
            this.cbx_Part.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Part.FormattingEnabled = true;
            this.cbx_Part.Location = new System.Drawing.Point(413, 18);
            this.cbx_Part.Name = "cbx_Part";
            this.cbx_Part.Size = new System.Drawing.Size(175, 21);
            this.cbx_Part.TabIndex = 5;
            this.cbx_Part.SelectedIndexChanged += new System.EventHandler(this.cbx_Part_SelectedIndexChanged);
            // 
            // lbl_PartNumber
            // 
            this.lbl_PartNumber.AutoSize = true;
            this.lbl_PartNumber.Location = new System.Drawing.Point(368, 21);
            this.lbl_PartNumber.Name = "lbl_PartNumber";
            this.lbl_PartNumber.Size = new System.Drawing.Size(39, 13);
            this.lbl_PartNumber.TabIndex = 4;
            this.lbl_PartNumber.Text = "Part #:";
            // 
            // cbx_Manufacturer
            // 
            this.cbx_Manufacturer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Manufacturer.FormattingEnabled = true;
            this.cbx_Manufacturer.Location = new System.Drawing.Point(228, 18);
            this.cbx_Manufacturer.Name = "cbx_Manufacturer";
            this.cbx_Manufacturer.Size = new System.Drawing.Size(136, 21);
            this.cbx_Manufacturer.TabIndex = 3;
            this.cbx_Manufacturer.SelectedIndexChanged += new System.EventHandler(this.cbx_Manufacturer_SelectedIndexChanged);
            // 
            // lbl_Manufacturer
            // 
            this.lbl_Manufacturer.AutoSize = true;
            this.lbl_Manufacturer.Location = new System.Drawing.Point(149, 21);
            this.lbl_Manufacturer.Name = "lbl_Manufacturer";
            this.lbl_Manufacturer.Size = new System.Drawing.Size(73, 13);
            this.lbl_Manufacturer.TabIndex = 2;
            this.lbl_Manufacturer.Text = "Manufacturer:";
            // 
            // cbx_Type
            // 
            this.cbx_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Type.FormattingEnabled = true;
            this.cbx_Type.Location = new System.Drawing.Point(46, 18);
            this.cbx_Type.Name = "cbx_Type";
            this.cbx_Type.Size = new System.Drawing.Size(97, 21);
            this.cbx_Type.TabIndex = 1;
            this.cbx_Type.SelectedIndexChanged += new System.EventHandler(this.cbx_Type_SelectedIndexChanged);
            // 
            // lbl_Type
            // 
            this.lbl_Type.AutoSize = true;
            this.lbl_Type.Location = new System.Drawing.Point(6, 21);
            this.lbl_Type.Name = "lbl_Type";
            this.lbl_Type.Size = new System.Drawing.Size(34, 13);
            this.lbl_Type.TabIndex = 0;
            this.lbl_Type.Text = "Type:";
            // 
            // gbx_Info
            // 
            this.gbx_Info.Controls.Add(this.cbx_Command);
            this.gbx_Info.Controls.Add(this.lbl_Command);
            this.gbx_Info.Controls.Add(this.cbx_PageSize);
            this.gbx_Info.Controls.Add(this.lbl_PageSize);
            this.gbx_Info.Controls.Add(this.cbx_ChipSize);
            this.gbx_Info.Controls.Add(this.label1);
            this.gbx_Info.Location = new System.Drawing.Point(3, 139);
            this.gbx_Info.Name = "gbx_Info";
            this.gbx_Info.Size = new System.Drawing.Size(504, 55);
            this.gbx_Info.TabIndex = 3;
            this.gbx_Info.TabStop = false;
            this.gbx_Info.Text = "Chip Information";
            // 
            // cbx_Command
            // 
            this.cbx_Command.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Command.FormattingEnabled = true;
            this.cbx_Command.Location = new System.Drawing.Point(388, 22);
            this.cbx_Command.Name = "cbx_Command";
            this.cbx_Command.Size = new System.Drawing.Size(102, 21);
            this.cbx_Command.TabIndex = 5;
            // 
            // lbl_Command
            // 
            this.lbl_Command.AutoSize = true;
            this.lbl_Command.Location = new System.Drawing.Point(305, 25);
            this.lbl_Command.Name = "lbl_Command";
            this.lbl_Command.Size = new System.Drawing.Size(77, 13);
            this.lbl_Command.TabIndex = 4;
            this.lbl_Command.Text = "SPI Command:";
            // 
            // cbx_PageSize
            // 
            this.cbx_PageSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_PageSize.FormattingEnabled = true;
            this.cbx_PageSize.Location = new System.Drawing.Point(213, 22);
            this.cbx_PageSize.Name = "cbx_PageSize";
            this.cbx_PageSize.Size = new System.Drawing.Size(77, 21);
            this.cbx_PageSize.TabIndex = 3;
            // 
            // lbl_PageSize
            // 
            this.lbl_PageSize.AutoSize = true;
            this.lbl_PageSize.Location = new System.Drawing.Point(149, 25);
            this.lbl_PageSize.Name = "lbl_PageSize";
            this.lbl_PageSize.Size = new System.Drawing.Size(58, 13);
            this.lbl_PageSize.TabIndex = 2;
            this.lbl_PageSize.Text = "Page Size:";
            // 
            // cbx_ChipSize
            // 
            this.cbx_ChipSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_ChipSize.FormattingEnabled = true;
            this.cbx_ChipSize.Location = new System.Drawing.Point(66, 22);
            this.cbx_ChipSize.Name = "cbx_ChipSize";
            this.cbx_ChipSize.Size = new System.Drawing.Size(77, 21);
            this.cbx_ChipSize.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chip Size:";
            // 
            // sts_Status
            // 
            this.sts_Status.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.sts_Status.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lbl_Status,
            this.lbl_FileSize,
            this.lbl_BitStatus,
            this.lbl_Operations,
            this.lbl_Empty,
            this.lbl_ConnectionStatus});
            this.sts_Status.Location = new System.Drawing.Point(0, 618);
            this.sts_Status.Name = "sts_Status";
            this.sts_Status.Size = new System.Drawing.Size(811, 22);
            this.sts_Status.TabIndex = 5;
            this.sts_Status.Text = "statusStrip1";
            // 
            // lbl_Status
            // 
            this.lbl_Status.Name = "lbl_Status";
            this.lbl_Status.Size = new System.Drawing.Size(0, 17);
            // 
            // lbl_FileSize
            // 
            this.lbl_FileSize.Name = "lbl_FileSize";
            this.lbl_FileSize.Size = new System.Drawing.Size(0, 17);
            // 
            // lbl_BitStatus
            // 
            this.lbl_BitStatus.Name = "lbl_BitStatus";
            this.lbl_BitStatus.Size = new System.Drawing.Size(0, 17);
            // 
            // lbl_Operations
            // 
            this.lbl_Operations.Name = "lbl_Operations";
            this.lbl_Operations.Size = new System.Drawing.Size(0, 17);
            // 
            // lbl_Empty
            // 
            this.lbl_Empty.Name = "lbl_Empty";
            this.lbl_Empty.Size = new System.Drawing.Size(0, 17);
            // 
            // lbl_ConnectionStatus
            // 
            this.lbl_ConnectionStatus.Name = "lbl_ConnectionStatus";
            this.lbl_ConnectionStatus.Size = new System.Drawing.Size(75, 17);
            this.lbl_ConnectionStatus.Text = "Not Connect";
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "Binary files (*.bin) | *.bin|All files (*.*) | *.*";
            // 
            // gbx_FontSize
            // 
            this.gbx_FontSize.Controls.Add(this.btn_FontSizeMinus);
            this.gbx_FontSize.Controls.Add(this.btn_FontSizePlus);
            this.gbx_FontSize.Location = new System.Drawing.Point(513, 139);
            this.gbx_FontSize.Name = "gbx_FontSize";
            this.gbx_FontSize.Size = new System.Drawing.Size(295, 55);
            this.gbx_FontSize.TabIndex = 6;
            this.gbx_FontSize.TabStop = false;
            this.gbx_FontSize.Text = "Font Size Control";
            // 
            // btn_FontSizeMinus
            // 
            this.btn_FontSizeMinus.Location = new System.Drawing.Point(157, 22);
            this.btn_FontSizeMinus.Name = "btn_FontSizeMinus";
            this.btn_FontSizeMinus.Size = new System.Drawing.Size(120, 23);
            this.btn_FontSizeMinus.TabIndex = 1;
            this.btn_FontSizeMinus.Text = "Editor Font Size -";
            this.btn_FontSizeMinus.UseVisualStyleBackColor = true;
            this.btn_FontSizeMinus.Click += new System.EventHandler(this.btn_FontSizeMinus_Click);
            // 
            // btn_FontSizePlus
            // 
            this.btn_FontSizePlus.Location = new System.Drawing.Point(17, 22);
            this.btn_FontSizePlus.Name = "btn_FontSizePlus";
            this.btn_FontSizePlus.Size = new System.Drawing.Size(120, 23);
            this.btn_FontSizePlus.TabIndex = 0;
            this.btn_FontSizePlus.Text = "Editor Font Size +";
            this.btn_FontSizePlus.UseVisualStyleBackColor = true;
            this.btn_FontSizePlus.Click += new System.EventHandler(this.btn_FontSizePlus_Click);
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "Binary files (*.bin) | *.bin|All files (*.*) | *.*";
            // 
            // pbr_Progress
            // 
            this.pbr_Progress.Location = new System.Drawing.Point(3, 591);
            this.pbr_Progress.Name = "pbr_Progress";
            this.pbr_Progress.Size = new System.Drawing.Size(805, 23);
            this.pbr_Progress.TabIndex = 7;
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // hbx_Edit
            // 
            this.hbx_Edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.hbx_Edit.ColumnInfoVisible = true;
            this.hbx_Edit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.hbx_Edit.LineInfoVisible = true;
            this.hbx_Edit.Location = new System.Drawing.Point(3, 200);
            this.hbx_Edit.Name = "hbx_Edit";
            this.hbx_Edit.ShadowSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(60)))), ((int)(((byte)(188)))), ((int)(((byte)(255)))));
            this.hbx_Edit.Size = new System.Drawing.Size(805, 385);
            this.hbx_Edit.StringViewVisible = true;
            this.hbx_Edit.TabIndex = 4;
            this.hbx_Edit.UseFixedBytesPerLine = true;
            this.hbx_Edit.VScrollBarVisible = true;
            this.hbx_Edit.CurrentLineChanged += new System.EventHandler(this.hbx_Edit_CurrentLineChanged);
            this.hbx_Edit.Copied += new System.EventHandler(this.hbx_Edit_Copied);
            this.hbx_Edit.CopiedHex += new System.EventHandler(this.hbx_Edit_CopiedHex);
            this.hbx_Edit.DragDrop += new System.Windows.Forms.DragEventHandler(this.hbx_Edit_DragDrop);
            this.hbx_Edit.DragEnter += new System.Windows.Forms.DragEventHandler(this.hbx_Edit_DragEnter);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 640);
            this.Controls.Add(this.pbr_Progress);
            this.Controls.Add(this.gbx_FontSize);
            this.Controls.Add(this.sts_Status);
            this.Controls.Add(this.hbx_Edit);
            this.Controls.Add(this.gbx_Info);
            this.Controls.Add(this.gbx_Chip);
            this.Controls.Add(this.tsp_Programmer);
            this.Controls.Add(this.msp_Programmer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.msp_Programmer;
            this.MinimumSize = new System.Drawing.Size(826, 610);
            this.Name = "frmMain";
            this.Padding = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " CH341A/CH347 Programmer V2.1 (Developed by Shichang Zhuo)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.msp_Programmer.ResumeLayout(false);
            this.msp_Programmer.PerformLayout();
            this.tsp_Programmer.ResumeLayout(false);
            this.tsp_Programmer.PerformLayout();
            this.gbx_Chip.ResumeLayout(false);
            this.gbx_Chip.PerformLayout();
            this.gbx_Info.ResumeLayout(false);
            this.gbx_Info.PerformLayout();
            this.sts_Status.ResumeLayout(false);
            this.sts_Status.PerformLayout();
            this.gbx_FontSize.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip msp_Programmer;
        private System.Windows.Forms.ToolStripMenuItem fileFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectICToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operationsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem autoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem eraseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem readToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verifyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blankCheckToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStrip tsp_Programmer;
        private System.Windows.Forms.ToolStripButton btn_Open;
        private System.Windows.Forms.ToolStripButton btn_Save;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btn_Read;
        private System.Windows.Forms.ToolStripButton btn_Erase;
        private System.Windows.Forms.ToolStripButton btn_Program;
        private System.Windows.Forms.ToolStripButton btn_Verify;
        private System.Windows.Forms.ToolStripMenuItem fillChipToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton btn_Auto;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btn_Blank;
        private System.Windows.Forms.ToolStripButton btn_Fill;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton btn_About;
        private System.Windows.Forms.GroupBox gbx_Chip;
        private System.Windows.Forms.ComboBox cbx_Type;
        private System.Windows.Forms.Label lbl_Type;
        private System.Windows.Forms.Button btn_ChipSearch;
        private System.Windows.Forms.Button btn_Detect;
        private System.Windows.Forms.ComboBox cbx_Part;
        private System.Windows.Forms.Label lbl_PartNumber;
        private System.Windows.Forms.ComboBox cbx_Manufacturer;
        private System.Windows.Forms.Label lbl_Manufacturer;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem copyHexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteHexToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem findToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem findNextToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goToToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.GroupBox gbx_Info;
        private System.Windows.Forms.ComboBox cbx_PageSize;
        private System.Windows.Forms.Label lbl_PageSize;
        private System.Windows.Forms.ComboBox cbx_ChipSize;
        private System.Windows.Forms.Label label1;
        private Be.Windows.Forms.HexBox hbx_Edit;
        private System.Windows.Forms.StatusStrip sts_Status;
        private System.Windows.Forms.ToolStripStatusLabel lbl_Status;
        private System.Windows.Forms.ComboBox cbx_Command;
        private System.Windows.Forms.Label lbl_Command;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.ToolStripStatusLabel lbl_FileSize;
        private System.Windows.Forms.ToolStripStatusLabel lbl_BitStatus;
        private System.Windows.Forms.GroupBox gbx_FontSize;
        private System.Windows.Forms.Button btn_FontSizePlus;
        private System.Windows.Forms.Button btn_FontSizeMinus;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ProgressBar pbr_Progress;
        private System.Windows.Forms.ToolStripStatusLabel lbl_Operations;
        private System.Windows.Forms.ToolStripMenuItem fileSlicerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileMergerToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel lbl_Empty;
        private System.Windows.Forms.ToolStripStatusLabel lbl_ConnectionStatus;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem programmerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cH347ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem i2CSpeedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem i2c3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem i2c2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem i2c1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem i2c0ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spi0SpeedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spi0ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spi1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spi2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spi3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spi4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spi5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spi6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spi7ToolStripMenuItem;
    }
}

