﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH341A_Programmer
{
    
    public enum CHIP_TYPE
    {
        NA,
        SPI,
        I2C
    }

    public enum SPI_COMMAND
    {
        NA,
        S25XX,
        S45XX,
        S95XX
    }

    public enum I2C_ADDRESS_TYPE
    {
        I2C_ADDR_TYPE_7BIT = 0,
        I2C_ADDR_TYPE_1BYTE = 1,
        I2C_ADDR_TYPE_1BYTE_1BIT = 2,
        I2C_ADDR_TYPE_1BYTE_2BIT = 3,
        I2C_ADDR_TYPE_1BYTE_3BIT = 4,
        I2C_ADDR_TYPE_2BYTE = 5,
        I2C_ADDR_TYPE_2BYTE_1BIT = 6,
    }

    public enum I2C_BYTE_ADDRESS
    {
        I2C_0BYTE_ADDR = 0,
        I2C_1BYTE_ADDR = 1,
        I2C_2BYTE_ADDR = 2
    }
}
