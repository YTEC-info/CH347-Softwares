﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH341A_Programmer
{
    public class Chip
    {
        private string _Manufacturer = "";
        private string _Name = "";
        private long _Size = 0;

        public Chip(string manufacturer, string name, long size)
        {
            _Manufacturer = manufacturer;
            _Name = name;
            _Size = size;
        }

        public string Manufacturer
        {
            get { return _Manufacturer; }
            set { _Manufacturer = value; }
        }

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public long Size
        {
            get { return _Size; }
            set { _Size = value; }
        }
    }
}
