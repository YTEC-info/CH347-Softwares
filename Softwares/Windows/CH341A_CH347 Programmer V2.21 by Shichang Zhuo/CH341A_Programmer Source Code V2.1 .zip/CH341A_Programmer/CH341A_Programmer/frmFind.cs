﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Be.Windows.Forms;

namespace CH341A_Programmer
{
    public partial class frmFind : Form
    {
        private FindOptions _findOptions;

        private HexBox _MainWindowHexBox = null;

        bool _finding;

        public FindOptions FindOptions
        {
            get
            {
                return _findOptions;
            }
            set
            {
                _findOptions = value;
                Reinitialize();
            }
        }

        public frmFind(ref HexBox hexBox)
        {
            InitializeComponent();

            _MainWindowHexBox = hexBox;
        }

        private void Reinitialize()
        {
            rbn_Text.Checked = _findOptions.Type == FindType.Text;
            tbx_Text.Text = _findOptions.Text;
            chk_MatchCases.Checked = _findOptions.MatchCase;

            rbn_Hex.Checked = _findOptions.Type == FindType.Hex;
        }

        public void FindNext()
        {
            if (!_findOptions.IsValid)
                return;

            btn_Find.Enabled = false;
            _finding = true;

            // start find process
            long res = _MainWindowHexBox.Find(_findOptions);

            btn_Find.Enabled = true;
            _finding = false;

            Application.DoEvents();

            if (res == -1) // -1 = no match
            {
                MessageBox.Show("Find has reached end of file!", Program.SoftwareName,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (res == -2) // -2 = find was aborted
            {
                return;
            }
            else // something was found
            {
                this.Close();

                Application.DoEvents();

                if (!_MainWindowHexBox.Focused)
                    _MainWindowHexBox.Focus();
            }
        }
        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            if (_finding)
                _MainWindowHexBox.AbortFind();
            else
                this.Close();
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            _findOptions.MatchCase = chk_MatchCases.Checked;

            _findOptions.Hex = rbn_Hex.Checked ? Tools.ConvertByteArrayFromHexString(tbx_Text.Text) : new byte[0];
            _findOptions.Text = tbx_Text.Text;
            _findOptions.Type = rbn_Hex.Checked ? FindType.Hex : FindType.Text;
            _findOptions.MatchCase = chk_MatchCases.Checked;
            _findOptions.IsValid = true;

            FindNext();
        }

        private void rbn_Hex_CheckedChanged(object sender, EventArgs e)
        {
            if (rbn_Hex.Checked)
            {
                chk_MatchCases.Checked = false;
            }
        }

        private void frmFind_Load(object sender, EventArgs e)
        {
            if (!tbx_Text.Focused)
                tbx_Text.Focus();
        }
    }
}
