﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using Be.Windows.Forms;


namespace CH341A_Programmer
{
    public partial class frmMain : Form
    {
        private ChipSettings _ChipSettings = null;
        private Chip _SelectedChip = null;

        private string _FileName = "";

        private frmFind _formFind = null;
        private FindOptions _findOptions = new FindOptions();

        private frmGoTo _formGoto = null;

        private frmChipSelection _formChipSelection = null;

        private UsbManager _UsbManager = null;

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            LoadChipType();
            LoadChipSize();
            LoadPageSize();
            LoadSpiCommand();

            LoadChipSettings();
            LoadManufacturers(CHIP_TYPE.NA);
            LoadChipNames(CHIP_TYPE.NA, "");

            InitialSetup();

            resizeWindow();
        }

        private void InitialSetup()
        {
            lbl_Command.Visible = false;
            cbx_Command.Visible = false;

            lbl_Empty.Text = string.Empty;
            lbl_Empty.Spring = true;

            hbx_Edit.Font = new Font(SystemFonts.MessageBoxFont.FontFamily, SystemFonts.MessageBoxFont.Size + float.Parse("2.0"), SystemFonts.MessageBoxFont.Style);

            ManageAbility();

            _UsbManager = new UsbManager();

            timer1.Enabled = true;
        }

        private void LoadChipType()
        {
            cbx_Type.Items.Clear();

            cbx_Type.Items.Add(new ComboboxItem { Text = "Chip Type", Value = CHIP_TYPE.NA });
            cbx_Type.Items.Add(new ComboboxItem { Text = "SPI (25 Series)", Value = CHIP_TYPE.SPI });
            cbx_Type.Items.Add(new ComboboxItem { Text = "I2C (24 Series)", Value = CHIP_TYPE.I2C });

            cbx_Type.SelectedIndex = 0;
        }

        private void LoadChipSize()
        {
            cbx_ChipSize.Items.Clear();

            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "Chip Size", Value = 0 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "64B", Value = 64 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "128B", Value = 128 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "256B", Value = 256 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "512B", Value = 512 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "1KB", Value = 1024 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "2KB", Value = 2048 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "4KB", Value = 4096 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "8KB", Value = 8192 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "16KB", Value = 16384 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "32KB", Value = 32768 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "64KB", Value = 65536 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "128KB", Value = 131072 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "256KB", Value = 262144 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "512KB", Value = 524288 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "1MB", Value = 1048576 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "2MB", Value = 2097152 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "4MB", Value = 4194304 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "8MB", Value = 8388608 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "16MB", Value = 16777216 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "32MB", Value = 33554432 });
            cbx_ChipSize.Items.Add(new ComboboxItem { Text = "64MB", Value = 67108864 });

            cbx_ChipSize.SelectedIndex = 0;
        }

        private void LoadPageSize()
        {
            cbx_PageSize.Items.Clear();

            cbx_PageSize.Items.Add(new ComboboxItem { Text = "Page Size", Value = 0 });
			cbx_PageSize.Items.Add(new ComboboxItem { Text = "1", Value = 1 });																   
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "4", Value = 4 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "8", Value = 8 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "16", Value = 16 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "32", Value = 32 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "64", Value = 64 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "128", Value = 128 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "256", Value = 256 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "264", Value = 264 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "512", Value = 512 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "528", Value = 528 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "1024", Value = 1024 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "1056", Value = 1056 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "SSTB", Value = -1 });
            cbx_PageSize.Items.Add(new ComboboxItem { Text = "SSTW", Value = -1 });

            cbx_PageSize.SelectedIndex = 0;
        }

        private void LoadSpiCommand()
        {
            cbx_Command.Items.Clear();

            cbx_Command.Items.Add(new ComboboxItem { Text = "SPI Command", Value = SPI_COMMAND.NA });
            cbx_Command.Items.Add(new ComboboxItem { Text = "25XX", Value = SPI_COMMAND.S25XX });
            cbx_Command.Items.Add(new ComboboxItem { Text = "45XX", Value = SPI_COMMAND.S45XX });
            cbx_Command.Items.Add(new ComboboxItem { Text = "95XX", Value = SPI_COMMAND.S95XX });

            cbx_Command.SelectedIndex = 0;
        }

        private void LoadChipSettings()
        {
            _ChipSettings = new ChipSettings();
            string errMsg = _ChipSettings.LoadChipList();

            if (errMsg != "")
                MessageBox.Show(errMsg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void LoadManufacturers(CHIP_TYPE type)
        {
            cbx_Manufacturer.Items.Clear();

            cbx_Manufacturer.Items.Add("Manufacturer");
            
            switch (type)
            {
                case CHIP_TYPE.SPI:
                    cbx_Manufacturer.Items.AddRange(_ChipSettings.GetManufacturers("SPI_Chip"));
                    break;
                case CHIP_TYPE.I2C:
                    cbx_Manufacturer.Items.AddRange(_ChipSettings.GetManufacturers("I2C_Chip"));
                    break;
            }

            cbx_Manufacturer.SelectedIndex = 0;
        }

        private void LoadChipNames(CHIP_TYPE type, string manufacturer)
        {
            cbx_Part.Items.Clear();

            cbx_Part.Items.Add(new ComboboxItem { Text = "Part #", Value = null });

            List<Chip> chipList = new List<Chip>();

            switch (type)
            {
                case CHIP_TYPE.SPI:
                    chipList.AddRange(_ChipSettings.GetChipList("SPI_Chip", manufacturer));
                    break;
                case CHIP_TYPE.I2C:
                    chipList.AddRange(_ChipSettings.GetChipList("I2C_Chip", manufacturer));
                    break;
            }

            foreach (Chip chip in chipList)
                cbx_Part.Items.Add(new ComboboxItem { Text = chip.Name, Value = chip });

            cbx_Part.SelectedIndex = 0;
        }

        private void SelectSize(long size)
        {
            for (int i = 0; i < cbx_ChipSize.Items.Count; ++i)
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.Items[i];
                long itemSize = long.Parse(cbi.Value.ToString());

                if (itemSize == size)
                {
                    cbx_ChipSize.SelectedIndex = i;
                    break;
                }
            }
        }

        private void SelectPageSize(string pageSize)
        {
            for (int i = 0; i < cbx_PageSize.Items.Count; ++i)
            {
                ComboboxItem cbi = (ComboboxItem)cbx_PageSize.Items[i];
                string itemSize = cbi.Text;

                if (itemSize == pageSize)
                {
                    cbx_PageSize.SelectedIndex = i;
                    break;
                }
            }
        }

        private void SelectSpiCommand(string cmd)
        {
            for (int i = 0; i < cbx_Command.Items.Count; ++i)
            {
                ComboboxItem cbi = (ComboboxItem)cbx_Command.Items[i];
                
                if ((cbi.Text == "25XX" && cmd == "25") ||
                    (cbi.Text == "45XX" && cmd == "45") ||
                    (cbi.Text == "95XX" && cmd == "95"))
                {
                    cbx_Command.SelectedIndex = i;
                    break;
                }

            }
        }

        private void ManageAbility(bool readFromChip = false)
        {
            if (hbx_Edit.ByteProvider == null)
            {
                saveToolStripMenuItem.Enabled = btn_Save.Enabled = false;

                findToolStripMenuItem.Enabled = false;
                findNextToolStripMenuItem.Enabled = false;
                goToToolStripMenuItem.Enabled = false;

                selectAllToolStripMenuItem.Enabled = false;
            }
            else
            {
                saveToolStripMenuItem.Enabled = btn_Save.Enabled = (hbx_Edit.ByteProvider.HasChanges() || readFromChip);

                findToolStripMenuItem.Enabled = true;
                findNextToolStripMenuItem.Enabled = true;
                goToToolStripMenuItem.Enabled = true;

                selectAllToolStripMenuItem.Enabled = true;
            }

            ManageAbilityForCopyAndPaste();
        }

        private void ManageAbilityForCopyAndPaste()
        {
            copyHexToolStripMenuItem.Enabled = copyToolStripMenuItem.Enabled = hbx_Edit.CanCopy();

            cutToolStripMenuItem.Enabled = hbx_Edit.CanCut();
            pasteToolStripMenuItem.Enabled = hbx_Edit.CanPaste();
            pasteHexToolStripMenuItem.Enabled = hbx_Edit.CanPasteHex();
        }

        public void OpenFile()
        {
            if(openFileDialog.ShowDialog() == DialogResult.OK)
            {
                OpenFile(openFileDialog.FileName);
            }
        }

        public void SetChip(Chip chip)
        {
            _SelectedChip = chip;

            string chipType = chip.GetType().Name;
            CHIP_TYPE type = CHIP_TYPE.NA;
            switch (chipType)
            {
                case "SPI_Chip":
                    type = CHIP_TYPE.SPI;
                    break;
                case "I2C_Chip":
                    type = CHIP_TYPE.I2C;
                    break;
            }
            for (int i = 0; i < cbx_Type.Items.Count; ++i)
            {
                if ((CHIP_TYPE)((ComboboxItem)cbx_Type.Items[i]).Value == type)
                {
                    cbx_Type.SelectedIndex = i;
                    break;
                }
            }

            string manufacturer = chip.Manufacturer;
            for (int i = 0; i < cbx_Manufacturer.Items.Count; ++i)
            {
                if (cbx_Manufacturer.Items[i].ToString() == manufacturer)
                {
                    cbx_Manufacturer.SelectedIndex = i;
                    break;
                }
            }

            for (int i = 0; i < cbx_Part.Items.Count; ++i)
            {
                if (cbx_Part.Items[i].ToString() == chip.Name)
                {
                    cbx_Part.SelectedIndex = i;
                    break;
                }
            }
        }

        private void OpenFile(string fileName)
        {
            if (!File.Exists(fileName))
            {
                Program.ShowMessage("The file you have selected does not exist.");
                return;
            }

            if (CloseFile() == DialogResult.Cancel)
                return;

            try
            {
                DynamicFileByteProvider dynamicFileByteProvider;
                try
                {
                    // try to open in write mode
                    dynamicFileByteProvider = new DynamicFileByteProvider(fileName);
                    dynamicFileByteProvider.Changed += new EventHandler(byteProvider_Changed);
                    dynamicFileByteProvider.LengthChanged += new EventHandler(byteProvider_LengthChanged);
                }
                catch (IOException) // write mode failed
                {
                    try
                    {
                        // try to open in read-only mode
                        dynamicFileByteProvider = new DynamicFileByteProvider(fileName, true);
                        if (Program.ShowQuestion("The file is locked by another process. Do you want to continue and open it in read-only mode?") == DialogResult.No)
                        {
                            dynamicFileByteProvider.Dispose();
                            return;
                        }
                    }
                    catch (IOException) // read-only also failed
                    {
                        // file cannot be opened
                        Program.ShowError("File is locked by another process and cannot be opened!");
                        return;
                    }
                }

                hbx_Edit.ByteProvider = dynamicFileByteProvider;
                _FileName = fileName;

                UpdateFileSizeStatus();
            }
            catch (Exception ex1)
            {
                Program.ShowError(ex1);
                return;
            }
            finally
            {

                ManageAbility();
            }
        }

        private void SaveFile()
        {
            if (hbx_Edit.ByteProvider == null)
                return;

            try
            {
                DynamicFileByteProvider dynamicFileByteProvider = hbx_Edit.ByteProvider as DynamicFileByteProvider;

                if (_FileName == "")
                {
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        _FileName = saveFileDialog.FileName;
                        string errMsg = dynamicFileByteProvider.SaveFile(_FileName);

                        if (errMsg == "")
                        {
                            MessageBox.Show("The file has been saved successfully to (" + _FileName + ").", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show(errMsg, Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    
                    dynamicFileByteProvider.ApplyChanges();
                }
            }
            catch (Exception ex1)
            {
                Program.ShowError(ex1);
            }
            finally
            {
                ManageAbility();
            }
        }

        private void CleanUp()
        {
            if (hbx_Edit.ByteProvider != null)
            {
                IDisposable byteProvider = hbx_Edit.ByteProvider as IDisposable;
                if (byteProvider != null)
                    byteProvider.Dispose();
                hbx_Edit.ByteProvider = null;
            }
            _FileName = null;
        }

        private DialogResult CloseFile()
        {
            if (hbx_Edit.ByteProvider == null)
                return DialogResult.OK;

            try

            {
                if (hbx_Edit.ByteProvider != null && hbx_Edit.ByteProvider.HasChanges())
                {
                    DialogResult res = MessageBox.Show("The file has been changed. Do you want to save changes?",
                        Program.SoftwareName,
                        MessageBoxButtons.YesNoCancel,
                        MessageBoxIcon.Warning);

                    if (res == DialogResult.Yes)
                    {
                        SaveFile();
                        CleanUp();
                    }
                    else if (res == DialogResult.No)
                    {
                        CleanUp();
                    }
                    else if (res == DialogResult.Cancel)
                    {
                        return res;
                    }

                    return res;
                }
                else
                {
                    CleanUp();
                    return DialogResult.OK;
                }
            }
            finally
            {
                ManageAbility();
            }
        }

        private void UpdateFileSizeStatus()
        {
            if (hbx_Edit.ByteProvider == null)
                lbl_FileSize.Text = string.Empty;
            else
                lbl_FileSize.Text = Tools.GetDisplayBytes(this.hbx_Edit.ByteProvider.Length);
        }

        private void Find()
        {
            ShowFind();
        }

        private frmFind ShowFind()
        {
            if (_formFind == null || _formFind.IsDisposed)
            {
                _formFind = new frmFind(ref hbx_Edit);
                _formFind.FindOptions = _findOptions;
                _formFind.Show(this);
            }
            else
            {
                _formFind.Focus();
            }
            return _formFind;
        }

        private void GoTo()
        {
            if (_formGoto == null || _formGoto.IsDisposed)
            {
                _formGoto = new frmGoTo(ref hbx_Edit);
                _formGoto.SetMaxByteIndex(hbx_Edit.ByteProvider.Length);
                _formGoto.SetDefaultValue(hbx_Edit.SelectionStart);
                _formGoto.Show(this);
            }
           
        }

        private void SearchChip()
        {
            if (_formChipSelection == null || _formChipSelection.IsDisposed)
            {
                _formChipSelection = new frmChipSelection(_ChipSettings, this);
                _formChipSelection.Show(this);
            }
        }

        private void ReadChip()
        {
            UsbManager.Start = DateTime.Now;

            if (CloseFile() == DialogResult.Cancel)
                return;

            ComboboxItem cbi = (ComboboxItem)cbx_Type.SelectedItem;

            CHIP_TYPE type = (CHIP_TYPE)cbi.Value;

            if (type == CHIP_TYPE.SPI)
                ReadSPIChip();
            else if (type == CHIP_TYPE.I2C)
                ReadI2CChip();
        }

        private void ReadSPIChip()
        {
            try
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.SelectedItem;

                int size = (int)cbi.Value;

                ComboboxItem cbic = (ComboboxItem)cbx_Part.SelectedItem;

                SPI_Chip chip = (SPI_Chip)cbic.Value;
                string command = chip.SpiCommand;
                string pageSize = chip.PageSize;
                int otp = chip.OTP;

                byte[] result = UsbManager.ReadSPIChip(size, pageSize, command, otp, this.pbr_Progress, this.lbl_Operations);

                MemoryStream ms = new MemoryStream(result);

                DynamicFileByteProvider dynamicFileByteProvider;

                dynamicFileByteProvider = new DynamicFileByteProvider(ms);
                dynamicFileByteProvider.Changed += new EventHandler(byteProvider_Changed);
                dynamicFileByteProvider.LengthChanged += new EventHandler(byteProvider_LengthChanged);

                hbx_Edit.ByteProvider = dynamicFileByteProvider;

                UpdateFileSizeStatus();

                _FileName = "";

                MessageBox.Show("The chip has been read successfully." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Program.ShowError(ex);
                return;
            }
            finally
            {

                ManageAbility(true);
            }
        }

        private void ReadI2CChip()
        {
            
            try
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.SelectedItem;

                int size = (int)cbi.Value;

                ComboboxItem cbic = (ComboboxItem)cbx_Part.SelectedItem;

                I2C_Chip chip = (I2C_Chip)cbic.Value;
                int addressType = chip.AddressType;
                int pageSize = int.Parse(chip.PageSize);

                byte[] result = UsbManager.ReadI2CChip(size, addressType, pageSize, this.pbr_Progress, this.lbl_Operations);

                MemoryStream ms = new MemoryStream(result);

                DynamicFileByteProvider dynamicFileByteProvider;

                dynamicFileByteProvider = new DynamicFileByteProvider(ms);
                dynamicFileByteProvider.Changed += new EventHandler(byteProvider_Changed);
                dynamicFileByteProvider.LengthChanged += new EventHandler(byteProvider_LengthChanged);

                hbx_Edit.ByteProvider = dynamicFileByteProvider;

                UpdateFileSizeStatus();

                _FileName = "";

                MessageBox.Show("The chip has been read successfully." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Program.ShowError(ex);
                return;
            }
            finally
            {

                ManageAbility(true);
            }
        }

        private void BlankCheck()
        {
            UsbManager.Start = DateTime.Now;

            ComboboxItem cbi = (ComboboxItem)cbx_Type.SelectedItem;

            CHIP_TYPE type = (CHIP_TYPE)cbi.Value;

            if (type == CHIP_TYPE.SPI)
                BlankCheckSPIChip();
            else if (type == CHIP_TYPE.I2C)
                BlankCheckI2CChip();
        }

        private void BlankCheckSPIChip()
        {
            try
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.SelectedItem;

                int size = (int)cbi.Value;

                ComboboxItem cbic = (ComboboxItem)cbx_Part.SelectedItem;

                SPI_Chip chip = (SPI_Chip)cbic.Value;
                string command = chip.SpiCommand;
                string pageSize = chip.PageSize;
                int otp = chip.OTP;

                byte[] result = UsbManager.ReadSPIChip(size, pageSize, command, otp, this.pbr_Progress, this.lbl_Operations);

                bool isBlank = true;
                for (long i = 0; i < result.Length; ++i)
                {
                    if (result[i] != 0xFF)
                    {
                        isBlank = false;
                        break;
                    }
                }

                if (!isBlank)
                    MessageBox.Show("The chip is not blank." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                    MessageBox.Show("The chip is blank." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Program.ShowError(ex);
                return;
            }
            finally
            {

                ManageAbility(true);
            }
        }

        private void BlankCheckI2CChip()
        {

            try
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.SelectedItem;

                int size = (int)cbi.Value;

                ComboboxItem cbic = (ComboboxItem)cbx_Part.SelectedItem;

                I2C_Chip chip = (I2C_Chip)cbic.Value;
                int addressType = chip.AddressType;
                int pageSize = int.Parse(chip.PageSize);

                byte[] result = UsbManager.ReadI2CChip(size, addressType, pageSize, this.pbr_Progress, this.lbl_Operations);

                bool isBlank = true;
                for (long i = 0; i < result.Length; ++i)
                {
                    if (result[i] != 0xFF)
                    {
                        isBlank = false;
                        break;
                    }
                }

                if (!isBlank)
                    MessageBox.Show("The chip is not blank." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                    MessageBox.Show("The chip is blank." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Program.ShowError(ex);
                return;
            }
            finally
            {

                ManageAbility(true);
            }
        }

        private void VerifyChip()
        {
            UsbManager.Start = DateTime.Now;

            ComboboxItem cbi = (ComboboxItem)cbx_Type.SelectedItem;

            CHIP_TYPE type = (CHIP_TYPE)cbi.Value;

            if (type == CHIP_TYPE.SPI)
                VerifySPIChip();
            else if (type == CHIP_TYPE.I2C)
                VerifyI2CChip();
        }

        private void VerifySPIChip()
        {
            try
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.SelectedItem;

                int size = (int)cbi.Value;

                ComboboxItem cbic = (ComboboxItem)cbx_Part.SelectedItem;

                SPI_Chip chip = (SPI_Chip)cbic.Value;
                string command = chip.SpiCommand;
                string pageSize = chip.PageSize;
                int otp = chip.OTP;

                byte[] result = UsbManager.ReadSPIChip(size, pageSize, command, otp, this.pbr_Progress, this.lbl_Operations);

                DynamicFileByteProvider provider = (DynamicFileByteProvider)hbx_Edit.ByteProvider;
                provider.ApplyChanges();
                Stream stream = provider.GetStream();

                stream.Position = 0;

                byte[] fromEditor = Tools.ReadToEnd(stream);

                bool foundDifference = false;
                for (long i = 0; i < result.Length; ++i)
                {
                    if (result[i] != fromEditor[i])
                    {
                        foundDifference = true;
                        break;
                    }
                }

                if (foundDifference)
                    MessageBox.Show("The chip was not matching the current document." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                    MessageBox.Show("The chip has been verified successfully. All content are the same." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Program.ShowError(ex);
                return;
            }
            finally
            {

                ManageAbility(true);
            }
        }

        private void VerifyI2CChip()
        {

            try
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.SelectedItem;

                int size = (int)cbi.Value;

                ComboboxItem cbic = (ComboboxItem)cbx_Part.SelectedItem;

                I2C_Chip chip = (I2C_Chip)cbic.Value;
                int addressType = chip.AddressType;
                int pageSize = int.Parse(chip.PageSize);

                byte[] result = UsbManager.ReadI2CChip(size, addressType, pageSize, this.pbr_Progress, this.lbl_Operations);

                DynamicFileByteProvider provider = (DynamicFileByteProvider)hbx_Edit.ByteProvider;
                provider.ApplyChanges();
                Stream stream = provider.GetStream();

                stream.Position = 0;

                byte[] fromEditor = Tools.ReadToEnd(stream);

                bool foundDifference = false;
                for (long i = 0; i < result.Length; ++i)
                {
                    if (result[i] != fromEditor[i])
                    {
                        foundDifference = true;
                        break;
                    }
                }

                if (foundDifference)
                    MessageBox.Show("The chip was not matching the current document." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                    MessageBox.Show("The chip has been verified successfully. All content are the same." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Program.ShowError(ex);
                return;
            }
            finally
            {

                ManageAbility(true);
            }
        }

        private void WriteChip(bool auto)
        {
            if (!auto)
            {
                if (!(ConfirmAction("Are you sure to program the chip?") == DialogResult.Yes))
                    return;
            }

            UsbManager.Start = DateTime.Now;

            ComboboxItem cbi = (ComboboxItem)cbx_Type.SelectedItem;

            CHIP_TYPE type = (CHIP_TYPE)cbi.Value;

            if (type == CHIP_TYPE.SPI)
                WriteSPIChip(auto);
            else if (type == CHIP_TYPE.I2C)
                WriteI2CChip(auto);
        }

        private void WriteSPIChip(bool auto)
        {
            try
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.SelectedItem;

                int size = (int)cbi.Value;

                ComboboxItem cbic = (ComboboxItem)cbx_Part.SelectedItem;

                SPI_Chip chip = (SPI_Chip)cbic.Value;
                string command = chip.SpiCommand;
                string pageSize = chip.PageSize;
                int otp = chip.OTP;

                DynamicFileByteProvider provider = (DynamicFileByteProvider)hbx_Edit.ByteProvider;
                provider.ApplyChanges();
                Stream stream = provider.GetStream();

                MemoryStream ms = new MemoryStream();
                //stream.CopyTo(ms);
                stream.Position = 0;
                byte[] buffer = new byte[128];
                int bytesRead = stream.Read(buffer, 0, 128);
                while (bytesRead > 0)
                {
                    ms.Write(buffer, 0, bytesRead);
                    bytesRead = stream.Read(buffer, 0, 128);
                }


                if (stream.Length > size)
                {
                    MessageBox.Show("The data you are trying to program is bigger than the chip size.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else if (stream.Length < size)
                {
                    DialogResult dr =  MessageBox.Show("The data you are trying to program is smaller than the chip size. The rest of the chip will be filled with FF. Are you sure to continue?", Program.SoftwareName, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (dr != DialogResult.Yes)
                        return;

                    // Change to only write content that has data for 25 chips
                    // For 45 and 95 chips, it will still write to the whole chip
                    if (command == "45" || command == "95")
                    {
                        ms.Position = ms.Length;

                        byte[] remaining = new byte[size - ms.Length];
                        for (int i = 0; i < remaining.Length; ++i)
                            remaining[i] = 0xFF;

                        ms.Write(remaining, 0, remaining.Length);
                    }
                    
                }

                EraseSPIChip(true); // SPI chip need to be earsed before write to it

                UsbManager.WriteSPIChip(ms, size, pageSize, command, otp, this.pbr_Progress, this.lbl_Operations);

                ms.Close();
                ms.Dispose();

                UpdateFileSizeStatus();

                _FileName = "";

                if (!auto)
                    MessageBox.Show("The chip has been written successfully." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Program.ShowError(ex);
                return;
            }
            finally
            {

                ManageAbility(true);
            }
        }

        private void WriteI2CChip(bool auto)
        {

            try
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.SelectedItem;

                int size = (int)cbi.Value;

                ComboboxItem cbic = (ComboboxItem)cbx_Part.SelectedItem;

                I2C_Chip chip = (I2C_Chip)cbic.Value;
                int addressType = chip.AddressType;
                int pageSize = int.Parse(chip.PageSize);

                DynamicFileByteProvider provider = (DynamicFileByteProvider)hbx_Edit.ByteProvider;
                provider.ApplyChanges();
                Stream stream = provider.GetStream();

                MemoryStream ms = new MemoryStream();
                stream.CopyTo(ms);

                if (stream.Length > size)
                {
                    MessageBox.Show("The data you are trying to program is bigger than the chip size.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else if (stream.Length < size)
                {
                    DialogResult dr = MessageBox.Show("The data you are trying to program is smaller than the chip size. The rest of the chip will be filled with FF. Are you sure to continue?", Program.SoftwareName, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (dr != DialogResult.Yes)
                        return;

                    ms.Position = ms.Length;

                    byte[] remaining = new byte[size - ms.Length];
                    for (int i = 0; i < remaining.Length; ++i)
                        remaining[i] = 0xFF;

                    ms.Write(remaining, 0, remaining.Length);
                }

                UsbManager.WriteI2CChip(stream, size, addressType, pageSize, this.pbr_Progress, this.lbl_Operations);

                ms.Close();
                ms.Dispose();

                UpdateFileSizeStatus();

                _FileName = "";

                if (!auto)
                    MessageBox.Show("The chip has been written successfully." + " Time elapsed: " + UsbManager.GetElapsedTime(UsbManager.Start, DateTime.Now), Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Program.ShowError(ex);
                return;
            }
            finally
            {

                ManageAbility(true);
            }
        }

        private void EraseChip(bool auto)
        {
            if (!auto)
            {
                if (!(ConfirmAction("Are you sure to earse the chip?") == DialogResult.Yes))
                    return;
            }

            ComboboxItem cbi = (ComboboxItem)cbx_Type.SelectedItem;

            CHIP_TYPE type = (CHIP_TYPE)cbi.Value;

            if (type == CHIP_TYPE.SPI)
                EraseSPIChip(auto);
            else if (type == CHIP_TYPE.I2C)
                EraseI2CChip(auto);
        }

        private void EraseSPIChip(bool auto)
        {
            try
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.SelectedItem;

                int size = (int)cbi.Value;

                ComboboxItem cbic = (ComboboxItem)cbx_Part.SelectedItem;

                SPI_Chip chip = (SPI_Chip)cbic.Value;
                string command = chip.SpiCommand;
                string pageSize = chip.PageSize;
                int otp = chip.OTP;

                byte[] emptyStream = new byte[size];
                UsbManager.memset(emptyStream, 0xFF, size);
                MemoryStream ms = new MemoryStream(emptyStream);

                if (!auto)
                {
                    DynamicFileByteProvider dynamicFileByteProvider;

                    dynamicFileByteProvider = new DynamicFileByteProvider(ms);
                    dynamicFileByteProvider.Changed += new EventHandler(byteProvider_Changed);
                    dynamicFileByteProvider.LengthChanged += new EventHandler(byteProvider_LengthChanged);

                    hbx_Edit.ByteProvider = dynamicFileByteProvider;
                }

                if (command == "95")
                {
                    UsbManager.WriteSPIChip(ms, size, pageSize, command, otp, this.pbr_Progress, this.lbl_Operations);
                }
                else if (command == "25")
                {
                    UsbManager.EraseSPIChip25(this.lbl_Operations);
                }
                else if (command == "45")
                {
                    UsbManager.EraseSPIChip45(this.lbl_Operations);
                }

                UpdateFileSizeStatus();

                _FileName = "";

                if (!auto)
                    MessageBox.Show("The chip has been earsed successfully.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Program.ShowError(ex);
                return;
            }
            finally
            {

                ManageAbility(true);
            }
        }

        private void EraseI2CChip(bool auto)
        {

            try
            {
                ComboboxItem cbi = (ComboboxItem)cbx_ChipSize.SelectedItem;

                int size = (int)cbi.Value;

                ComboboxItem cbic = (ComboboxItem)cbx_Part.SelectedItem;

                I2C_Chip chip = (I2C_Chip)cbic.Value;
                int addressType = chip.AddressType;
                int pageSize = int.Parse(chip.PageSize);

                byte[] emptyStream = new byte[size];
                UsbManager.memset(emptyStream, 0xFF, size);
                MemoryStream ms = new MemoryStream(emptyStream);

                if (!auto)
                {
                    DynamicFileByteProvider dynamicFileByteProvider;

                    dynamicFileByteProvider = new DynamicFileByteProvider(ms);
                    dynamicFileByteProvider.Changed += new EventHandler(byteProvider_Changed);
                    dynamicFileByteProvider.LengthChanged += new EventHandler(byteProvider_LengthChanged);

                    hbx_Edit.ByteProvider = dynamicFileByteProvider;
                }

                UsbManager.WriteI2CChip(ms, size, addressType, pageSize, this.pbr_Progress, this.lbl_Operations);

                UpdateFileSizeStatus();

                _FileName = "";

                if (!auto)
                    MessageBox.Show("The chip has been earsed successfully.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Program.ShowError(ex);
                return;
            }
            finally
            {

                ManageAbility(true);
            }
        }

        private void AutoChip()
        {
            string[] chipId = UsbManager.ReadSPIChipID();

            if (chipId[0] != "000000" && chipId[0] != "FFFFFF")
            {
                frmAutoChip autoChip = new frmAutoChip(_ChipSettings, this, chipId);
                autoChip.Show();
            }
        }

        private DialogResult ConfirmAction(string message)
        {
            DialogResult result = MessageBox.Show(message, Program.SoftwareName, MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            return result;
        }

        private void FillBuffer()
        {
            frmFill fill = new frmFill(ref hbx_Edit);
            fill.Show();
        }

        private void About()
        {
            frmAbout about = new frmAbout();
            about.Show();
        }

        private bool IsChipSelected()
        {
            bool result = cbx_Part.SelectedIndex > 0 ? true : false;

            if (!result)
                MessageBox.Show("Please select the correct chip before any operations.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Warning);

            return result;
        }

        private void byteProvider_Changed(object sender, EventArgs e)
        {
            ManageAbility();
        }

        private void byteProvider_LengthChanged(object sender, EventArgs e)
        {
            UpdateFileSizeStatus();
        }

        private void cbx_Type_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboboxItem cbi = (ComboboxItem)cbx_Type.SelectedItem;

            CHIP_TYPE type = (CHIP_TYPE)cbi.Value;

            if (type == CHIP_TYPE.SPI)
            {
                lbl_Command.Visible = true;
                cbx_Command.Visible = true;
            }
            else
            {
                lbl_Command.Visible = false;
                cbx_Command.Visible = false;
            }

            LoadManufacturers(type);
        }

        private void cbx_Manufacturer_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboboxItem cbi = (ComboboxItem)cbx_Type.SelectedItem;

            CHIP_TYPE type = (CHIP_TYPE)cbi.Value;

            string manufacturer = cbx_Manufacturer.SelectedItem.ToString();

            LoadChipNames(type, manufacturer);
        }

        private void cbx_Part_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbx_ChipSize.Items.Count > 0)
                cbx_ChipSize.SelectedIndex = 0;
            if (cbx_PageSize.Items.Count > 0)
                cbx_PageSize.SelectedIndex = 0;
            if (cbx_Command.Items.Count > 0)
                cbx_Command.SelectedIndex = 0;

            ComboboxItem cbi = (ComboboxItem)cbx_Part.SelectedItem;

            _SelectedChip = cbi.Value == null ? null : (Chip)cbi.Value;

            if (cbi.Value != null)
            {
                ComboboxItem cbit = (ComboboxItem)cbx_Type.SelectedItem;

                CHIP_TYPE type = (CHIP_TYPE)cbit.Value;

                switch (type)
                {
                    case CHIP_TYPE.SPI:
                        SPI_Chip sChip = (SPI_Chip)cbi.Value;
                        SelectSize(sChip.Size);
                        SelectPageSize(sChip.PageSize);
                        SelectSpiCommand(sChip.SpiCommand);
                        break;
                    case CHIP_TYPE.I2C:
                        I2C_Chip iChip = (I2C_Chip)cbi.Value;
                        SelectSize(iChip.Size);
                        SelectPageSize(iChip.PageSize);
                        break;
                }
            }
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            resizeWindow();
        }

        private void resizeWindow()
        {
            gbx_Chip.Width = this.Width - 23;
            gbx_FontSize.Width = this.Width - 533;
            hbx_Edit.Width = this.Width - 23;
            pbr_Progress.Width = this.Width - 23;
            hbx_Edit.Height = this.Height - 294;
            pbr_Progress.Top = hbx_Edit.Top + hbx_Edit.Height + 6;
        }

        private void btn_Open_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        private void hbx_Edit_DragDrop(object sender, DragEventArgs e)
        {
            object oFileNames = e.Data.GetData(DataFormats.FileDrop);
            string[] fileNames = (string[])oFileNames;
            if (fileNames.Length == 1)
            {
                OpenFile(fileNames[0]);
            }
        }

        private void hbx_Edit_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        private void hbx_Edit_Copied(object sender, EventArgs e)
        {
            ManageAbilityForCopyAndPaste();
        }

        private void hbx_Edit_CopiedHex(object sender, EventArgs e)
        {
            ManageAbilityForCopyAndPaste();
        }

        private void hbx_Edit_CurrentLineChanged(object sender, EventArgs e)
        {
            lbl_Status.Text = string.Format("Ln {0}    Col {1}",
                hbx_Edit.CurrentLine, hbx_Edit.CurrentPositionInLine);

            string bitPresentation = string.Empty;

            byte? currentByte = hbx_Edit.ByteProvider != null && hbx_Edit.ByteProvider.Length > hbx_Edit.SelectionStart
                ? hbx_Edit.ByteProvider.ReadByte(hbx_Edit.SelectionStart)
                : (byte?)null;

            BitInfo bitInfo = currentByte != null ? new BitInfo((byte)currentByte, hbx_Edit.SelectionStart) : null;

            if (bitInfo != null)
            {
                byte currentByteNotNull = (byte)currentByte;
                bitPresentation = string.Format("Bits of Byte {0}: {1}"
                    , hbx_Edit.SelectionStart
                    , bitInfo.ToString()
                    );
            }

            lbl_BitStatus.Text = bitPresentation;
        }

        private void btn_FontSizePlus_Click(object sender, EventArgs e)
        {
            hbx_Edit.Font = new Font(hbx_Edit.Font.FontFamily, hbx_Edit.Font.Size + float.Parse("1.0"), hbx_Edit.Font.Style);
        }

        private void btn_FontSizeMinus_Click(object sender, EventArgs e)
        {
            hbx_Edit.Font = new Font(hbx_Edit.Font.FontFamily, hbx_Edit.Font.Size - float.Parse("1.0"), hbx_Edit.Font.Style);
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (CloseFile() == DialogResult.Cancel)
                e.Cancel = true;
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hbx_Edit.Cut();
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hbx_Edit.Copy();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hbx_Edit.Paste();
        }

        private void copyHexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hbx_Edit.CopyHex();
        }

        private void pasteHexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hbx_Edit.PasteHex();
        }

        private void findToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowFind();
        }

        private void findNextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowFind().FindNext();
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hbx_Edit.SelectAll();
        }

        private void goToToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GoTo();
        }

        private void btn_ChipSearch_Click(object sender, EventArgs e)
        {
            SearchChip();
        }

        private void selectICToolStripMenuItem_Click(object sender, EventArgs e)
        {
			if (IsChipSelected() && CheckProgrammerIsConnected() > 0)													 
				SearchChip();
        }

        private void btn_Read_Click(object sender, EventArgs e)
        {
            if (IsChipSelected() && CheckProgrammerIsConnected() > 0)
                ReadChip();
        }

        private void btn_Program_Click(object sender, EventArgs e)
        {
            if (IsChipSelected() && CheckProgrammerIsConnected() > 0)
                WriteChip(false);
        }

        private void programToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsChipSelected() && CheckProgrammerIsConnected() > 0)
                WriteChip(false);
        }

        private void btn_Erase_Click(object sender, EventArgs e)
        {
            if (IsChipSelected() && CheckProgrammerIsConnected() > 0)
                EraseChip(false);
        }

        private void eraseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsChipSelected() && CheckProgrammerIsConnected() > 0)
                EraseChip(false);
        }

        private void btn_Verify_Click(object sender, EventArgs e)
        {
            if (IsChipSelected() && CheckProgrammerIsConnected() > 0)
                VerifyChip();
        }

        private void verifyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsChipSelected() && CheckProgrammerIsConnected() > 0)
                VerifyChip();
        }

        private void btn_Auto_Click(object sender, EventArgs e)
        {
            if (IsChipSelected() && CheckProgrammerIsConnected() > 0)
            {
                if (!(ConfirmAction("Are you sure to program the chip automatically?") == DialogResult.Yes))
                    return;

                //EraseChip(true);
                WriteChip(true);
                VerifyChip();
            }
        }

        private void autoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsChipSelected() && CheckProgrammerIsConnected() > 0)
            {
                if (!(ConfirmAction("Are you sure to program the chip automatically?") == DialogResult.Yes))
                    return;

                //EraseChip(true);
                WriteChip(true);
                VerifyChip();
            }
        }

        private void btn_Blank_Click(object sender, EventArgs e)
        {
            if(IsChipSelected() && CheckProgrammerIsConnected() > 0)
                BlankCheck();
        }

        private void blankCheckToolStripMenuItem_Click(object sender, EventArgs e)
        {
           if(IsChipSelected() && CheckProgrammerIsConnected() > 0)
                BlankCheck();
        }

        private void btn_Fill_Click(object sender, EventArgs e)
        {
            FillBuffer();
        }

        private void fillChipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FillBuffer();
        }

        private void btn_About_Click(object sender, EventArgs e)
        {
            About();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About();
        }

        private void btn_Detect_Click(object sender, EventArgs e)
        {
            if (CheckProgrammerIsConnected() > 0)
                AutoChip();
        }

        private void fileSlicerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DynamicFileByteProvider provider = (DynamicFileByteProvider)hbx_Edit.ByteProvider;

            if (provider == null)
            {
                MessageBox.Show("Please read a chip or load a data file before you can slice it.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            provider.ApplyChanges();
            Stream stream = provider.GetStream();

            MemoryStream ms = new MemoryStream();
            
            stream.Position = 0;
            byte[] buffer = new byte[128];
            int bytesRead = stream.Read(buffer, 0, 128);
            while (bytesRead > 0)
            {
                ms.Write(buffer, 0, 128);
                bytesRead = stream.Read(buffer, 0, 128);
            }

            frmSlicer slicer = new frmSlicer(ms);
            slicer.Show();
        }

        private void fileMergerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMerger merger = new frmMerger();
            merger.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!UsbManager.IsRunning)
            {
                //bool isConnect = UsbManager.IsProgrammerConnected();
                int connectedProgrammer = UsbManager.GetConnectedProgrammer();

                if (connectedProgrammer == 1)
                {
                    lbl_ConnectionStatus.Text = "CH341A Connected";
                    programmerToolStripMenuItem.Visible = false;
                }
                else if (connectedProgrammer == 7)
                {
                    lbl_ConnectionStatus.Text = "CH347 Connected";
                    programmerToolStripMenuItem.Visible = true;
                }
                else
                {
                    lbl_ConnectionStatus.Text = "No Programmer Connected";
                    programmerToolStripMenuItem.Visible = false;
                }
            }
        }

        private int CheckProgrammerIsConnected()
        {
            if (UsbManager.ConnectedProgrammer < 0)
                MessageBox.Show("CH341A/CH347 Programmer is not connected.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Error);

            return UsbManager.ConnectedProgrammer;
        }

        private void readToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsChipSelected() && CheckProgrammerIsConnected() > 0)
                ReadChip();
        }

        private void i2c3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllI2C();
            i2c3ToolStripMenuItem.Checked = true;
            UsbManager.I2C_Speed = 3;
        }

        private void i2c2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllI2C();
            i2c2ToolStripMenuItem.Checked = true;
            UsbManager.I2C_Speed = 2;
        }

        private void i2c1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllI2C();
            i2c1ToolStripMenuItem.Checked = true;
            UsbManager.I2C_Speed = 1;
        }

        private void i2c0ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllI2C();
            i2c0ToolStripMenuItem.Checked = true;
            UsbManager.I2C_Speed = 0;
        }

        private void UnCheckAllI2C()
        {
            i2c0ToolStripMenuItem.Checked = false;
            i2c1ToolStripMenuItem.Checked = false;
            i2c2ToolStripMenuItem.Checked = false;
            i2c3ToolStripMenuItem.Checked = false;
        }

        private void spi0ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllSPI();
            spi0ToolStripMenuItem.Checked = true;
            UsbManager.SPI_Speed = 0;
        }

        private void spi1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllSPI();
            spi1ToolStripMenuItem.Checked = true;
            UsbManager.SPI_Speed = 1;
        }

        private void spi2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllSPI();
            spi2ToolStripMenuItem.Checked = true;
            UsbManager.SPI_Speed = 2;
        }

        private void spi3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllSPI();
            spi3ToolStripMenuItem.Checked = true;
            UsbManager.SPI_Speed = 3;
        }

        private void spi4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllSPI();
            spi4ToolStripMenuItem.Checked = true;
            UsbManager.SPI_Speed = 4;
        }

        private void spi5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllSPI();
            spi5ToolStripMenuItem.Checked = true;
            UsbManager.SPI_Speed = 5;
        }

        private void spi6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllSPI();
            spi6ToolStripMenuItem.Checked = true;
            UsbManager.SPI_Speed = 6;
        }

        private void spi7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnCheckAllSPI();
            spi7ToolStripMenuItem.Checked = true;
            UsbManager.SPI_Speed = 7;
        }

        private void UnCheckAllSPI()
        {
            spi0ToolStripMenuItem.Checked = false;
            spi1ToolStripMenuItem.Checked = false;
            spi2ToolStripMenuItem.Checked = false;
            spi3ToolStripMenuItem.Checked = false;
            spi4ToolStripMenuItem.Checked = false;
            spi5ToolStripMenuItem.Checked = false;
            spi6ToolStripMenuItem.Checked = false;
            spi7ToolStripMenuItem.Checked = false;
        }
    }
}
