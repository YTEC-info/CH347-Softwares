﻿namespace CH341A_Programmer
{
    partial class frmAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAbout));
            this.lbl_Auther = new System.Windows.Forms.Label();
            this.lbl_Version = new System.Windows.Forms.Label();
            this.lbl_Link = new System.Windows.Forms.Label();
            this.tbx_Auther = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tbx_Link = new System.Windows.Forms.TextBox();
            this.tbx_Text = new System.Windows.Forms.TextBox();
            this.btn_OK = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Auther
            // 
            this.lbl_Auther.AutoSize = true;
            this.lbl_Auther.Location = new System.Drawing.Point(166, 22);
            this.lbl_Auther.Name = "lbl_Auther";
            this.lbl_Auther.Size = new System.Drawing.Size(41, 13);
            this.lbl_Auther.TabIndex = 1;
            this.lbl_Auther.Text = "Auther:";
            // 
            // lbl_Version
            // 
            this.lbl_Version.AutoSize = true;
            this.lbl_Version.Location = new System.Drawing.Point(166, 70);
            this.lbl_Version.Name = "lbl_Version";
            this.lbl_Version.Size = new System.Drawing.Size(45, 13);
            this.lbl_Version.TabIndex = 2;
            this.lbl_Version.Text = "Version:";
            // 
            // lbl_Link
            // 
            this.lbl_Link.AutoSize = true;
            this.lbl_Link.Location = new System.Drawing.Point(166, 115);
            this.lbl_Link.Name = "lbl_Link";
            this.lbl_Link.Size = new System.Drawing.Size(35, 13);
            this.lbl_Link.TabIndex = 3;
            this.lbl_Link.Text = "Email:";
            // 
            // tbx_Auther
            // 
            this.tbx_Auther.Location = new System.Drawing.Point(213, 19);
            this.tbx_Auther.Name = "tbx_Auther";
            this.tbx_Auther.ReadOnly = true;
            this.tbx_Auther.Size = new System.Drawing.Size(272, 20);
            this.tbx_Auther.TabIndex = 4;
            this.tbx_Auther.Text = "Shichang Zhuo";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(213, 67);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(272, 20);
            this.textBox2.TabIndex = 5;
            this.textBox2.Text = "V2.1";
            // 
            // tbx_Link
            // 
            this.tbx_Link.Location = new System.Drawing.Point(213, 112);
            this.tbx_Link.Name = "tbx_Link";
            this.tbx_Link.ReadOnly = true;
            this.tbx_Link.Size = new System.Drawing.Size(272, 20);
            this.tbx_Link.TabIndex = 6;
            this.tbx_Link.Text = "zhuoshichang@hotmail.com";
            // 
            // tbx_Text
            // 
            this.tbx_Text.Location = new System.Drawing.Point(12, 155);
            this.tbx_Text.Multiline = true;
            this.tbx_Text.Name = "tbx_Text";
            this.tbx_Text.ReadOnly = true;
            this.tbx_Text.Size = new System.Drawing.Size(473, 123);
            this.tbx_Text.TabIndex = 7;
            this.tbx_Text.Text = resources.GetString("tbx_Text.Text");
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(396, 293);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 8;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CH341A_Programmer.images._30972_8_chip;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // frmAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 325);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.tbx_Text);
            this.Controls.Add(this.tbx_Link);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.tbx_Auther);
            this.Controls.Add(this.lbl_Link);
            this.Controls.Add(this.lbl_Version);
            this.Controls.Add(this.lbl_Auther);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAbout";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "About CH341A/CH347 Programmer";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_Auther;
        private System.Windows.Forms.Label lbl_Version;
        private System.Windows.Forms.Label lbl_Link;
        private System.Windows.Forms.TextBox tbx_Auther;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox tbx_Link;
        private System.Windows.Forms.TextBox tbx_Text;
        private System.Windows.Forms.Button btn_OK;
    }
}