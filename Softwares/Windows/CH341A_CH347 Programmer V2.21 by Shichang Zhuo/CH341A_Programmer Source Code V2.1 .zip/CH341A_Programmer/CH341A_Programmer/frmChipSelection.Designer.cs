﻿namespace CH341A_Programmer
{
    partial class frmChipSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbx_Search = new System.Windows.Forms.GroupBox();
            this.tbx_Find = new System.Windows.Forms.TextBox();
            this.lbl_Find = new System.Windows.Forms.Label();
            this.gbx_Result = new System.Windows.Forms.GroupBox();
            this.dgv_Result = new System.Windows.Forms.DataGridView();
            this.gbx_Actions = new System.Windows.Forms.GroupBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Select = new System.Windows.Forms.Button();
            this.gbx_Search.SuspendLayout();
            this.gbx_Result.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Result)).BeginInit();
            this.gbx_Actions.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbx_Search
            // 
            this.gbx_Search.Controls.Add(this.tbx_Find);
            this.gbx_Search.Controls.Add(this.lbl_Find);
            this.gbx_Search.Location = new System.Drawing.Point(12, 12);
            this.gbx_Search.Name = "gbx_Search";
            this.gbx_Search.Size = new System.Drawing.Size(404, 64);
            this.gbx_Search.TabIndex = 0;
            this.gbx_Search.TabStop = false;
            this.gbx_Search.Text = "Search";
            // 
            // tbx_Find
            // 
            this.tbx_Find.Location = new System.Drawing.Point(51, 24);
            this.tbx_Find.Name = "tbx_Find";
            this.tbx_Find.Size = new System.Drawing.Size(330, 20);
            this.tbx_Find.TabIndex = 0;
            this.tbx_Find.TextChanged += new System.EventHandler(this.tbx_Find_TextChanged);
            // 
            // lbl_Find
            // 
            this.lbl_Find.AutoSize = true;
            this.lbl_Find.Location = new System.Drawing.Point(15, 27);
            this.lbl_Find.Name = "lbl_Find";
            this.lbl_Find.Size = new System.Drawing.Size(30, 13);
            this.lbl_Find.TabIndex = 0;
            this.lbl_Find.Text = "Find:";
            // 
            // gbx_Result
            // 
            this.gbx_Result.Controls.Add(this.dgv_Result);
            this.gbx_Result.Location = new System.Drawing.Point(12, 82);
            this.gbx_Result.Name = "gbx_Result";
            this.gbx_Result.Size = new System.Drawing.Size(404, 239);
            this.gbx_Result.TabIndex = 1;
            this.gbx_Result.TabStop = false;
            this.gbx_Result.Text = "Result";
            // 
            // dgv_Result
            // 
            this.dgv_Result.AllowUserToAddRows = false;
            this.dgv_Result.AllowUserToDeleteRows = false;
            this.dgv_Result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Result.Location = new System.Drawing.Point(6, 19);
            this.dgv_Result.MultiSelect = false;
            this.dgv_Result.Name = "dgv_Result";
            this.dgv_Result.ReadOnly = true;
            this.dgv_Result.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Result.Size = new System.Drawing.Size(392, 214);
            this.dgv_Result.TabIndex = 3;
            this.dgv_Result.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Result_CellDoubleClick);
            this.dgv_Result.SelectionChanged += new System.EventHandler(this.dgv_Result_SelectionChanged);
            // 
            // gbx_Actions
            // 
            this.gbx_Actions.Controls.Add(this.btn_Cancel);
            this.gbx_Actions.Controls.Add(this.btn_Select);
            this.gbx_Actions.Location = new System.Drawing.Point(12, 327);
            this.gbx_Actions.Name = "gbx_Actions";
            this.gbx_Actions.Size = new System.Drawing.Size(404, 55);
            this.gbx_Actions.TabIndex = 2;
            this.gbx_Actions.TabStop = false;
            this.gbx_Actions.Text = "Actions";
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.Location = new System.Drawing.Point(306, 19);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 2;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Select
            // 
            this.btn_Select.Location = new System.Drawing.Point(208, 19);
            this.btn_Select.Name = "btn_Select";
            this.btn_Select.Size = new System.Drawing.Size(75, 23);
            this.btn_Select.TabIndex = 1;
            this.btn_Select.Text = "Select";
            this.btn_Select.UseVisualStyleBackColor = true;
            this.btn_Select.Click += new System.EventHandler(this.btn_Select_Click);
            // 
            // frmChipSelection
            // 
            this.AcceptButton = this.btn_Select;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_Cancel;
            this.ClientSize = new System.Drawing.Size(429, 393);
            this.Controls.Add(this.gbx_Actions);
            this.Controls.Add(this.gbx_Result);
            this.Controls.Add(this.gbx_Search);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmChipSelection";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chip Selection";
            this.Load += new System.EventHandler(this.frmChipSelection_Load);
            this.gbx_Search.ResumeLayout(false);
            this.gbx_Search.PerformLayout();
            this.gbx_Result.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Result)).EndInit();
            this.gbx_Actions.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbx_Search;
        private System.Windows.Forms.TextBox tbx_Find;
        private System.Windows.Forms.Label lbl_Find;
        private System.Windows.Forms.GroupBox gbx_Result;
        private System.Windows.Forms.DataGridView dgv_Result;
        private System.Windows.Forms.GroupBox gbx_Actions;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Select;
    }
}