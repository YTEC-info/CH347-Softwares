﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH341A_Programmer
{
    public class I2C_Chip : Chip
    {
        private string _PageSize = "";
        private int _AddressType = -1;

        public I2C_Chip(string manufacturer, string name, long size, string pageSize, int addressType) : base(manufacturer, name, size)
        {
            _PageSize = pageSize;
            _AddressType = addressType;
        }

        public string PageSize
        {
            get { return _PageSize; }
            set { _PageSize = value; }
        }

        public int AddressType
        {
            get { return _AddressType; }
            set { _AddressType = value; }
        }
    }
}
