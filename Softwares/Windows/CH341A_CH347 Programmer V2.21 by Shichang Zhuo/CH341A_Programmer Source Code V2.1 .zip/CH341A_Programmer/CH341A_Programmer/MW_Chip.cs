﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH341A_Programmer
{
    public class MW_Chip : Chip
    {
        private int _AddressBitLength = 0;

        public MW_Chip(string manufacturer, string name, long size, int addressBitLength) : base(manufacturer, name, size)
        {
            _AddressBitLength = addressBitLength;
        }

        public int AddressBitLength
        {
            get { return _AddressBitLength; }
            set { _AddressBitLength = value; }
        }
    }
}
