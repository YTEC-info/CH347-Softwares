﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace CH341A_Programmer
{
    public class Tools
    {
        public static string GetDisplayBytes(long size)
        {
            const long multi = 1024;
            long kb = multi;
            long mb = kb * multi;
            long gb = mb * multi;
            long tb = gb * multi;

            const string BYTES = "Bytes";
            const string KB = "KB";
            const string MB = "MB";
            const string GB = "GB";
            const string TB = "TB";

            string result;
            if (size < kb)
                result = string.Format("{0} {1}", size, BYTES);
            else if (size < mb)
                result = string.Format("{0} {1} ({2} Bytes)",
                    ConvertToOneDigit(size, kb), KB, ConvertBytesDisplay(size));
            else if (size < gb)
                result = string.Format("{0} {1} ({2} Bytes)",
                    ConvertToOneDigit(size, mb), MB, ConvertBytesDisplay(size));
            else if (size < tb)
                result = string.Format("{0} {1} ({2} Bytes)",
                    ConvertToOneDigit(size, gb), GB, ConvertBytesDisplay(size));
            else
                result = string.Format("{0} {1} ({2} Bytes)",
                    ConvertToOneDigit(size, tb), TB, ConvertBytesDisplay(size));

            return result;
        }

        public static string ConvertBytesDisplay(long size)
        {
            return size.ToString("###,###,###,###,###", CultureInfo.CurrentCulture);
        }

        public static string ConvertToOneDigit(long size, long quan)
        {
            double quotient = (double)size / (double)quan;
            string result = quotient.ToString("0.#", CultureInfo.CurrentCulture);
            return result;
        }

        public static byte[] ConvertByteArrayFromHexString(string hex)
        {
            if (hex.Length %2 > 0)
            {
                hex = "0" + hex;
            }

            return Enumerable.Range(0, hex.Length)
                             .Where(x => x % 2 == 0)
                             .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                             .ToArray();
        }

        public static byte SetBit(byte value, byte bitNum)
        {
            return (byte)(value | (1 << bitNum));
        }

        public static byte ClearBit(byte value, byte bitNum)
        {
            return (byte)(value & (~(1 << bitNum)));
        }
        
        public static bool IsBitSet(byte value, byte bitNum)
        {
            return ((value >> bitNum) & 1) == 1;
        }

        public static byte[] ReadToEnd(System.IO.Stream stream)
        {
            long originalPosition = 0;

            if (stream.CanSeek)
            {
                originalPosition = stream.Position;
                stream.Position = 0;
            }

            try
            {
                byte[] readBuffer = new byte[4096];

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally
            {
                if (stream.CanSeek)
                {
                    stream.Position = originalPosition;
                }
            }
        }

        public static string IntToHexString(int inValue)
        {
            string str = Convert.ToString(inValue, 16).ToUpper();

            if (str.Length % 2 > 0)
                str = "0" + str;

            return str;
        }

        public static string IntToHexString(int[] inValue)
        {
            string str = "";

            foreach (int value in inValue)
                str += IntToHexString(value);

            return str;
        }

        public static string ByteToHexString(byte inValue)
        {
            string str = Convert.ToString(inValue, 16).ToUpper();

            if (str.Length % 2 > 0)
                str = "0" + str;

            return str;
        }

        public static string ByteToHexString(byte[] inValue)
        {
            string str = "";

            foreach (byte value in inValue)
                str += ByteToHexString(value);

            return str;
        }

        public static string LongToHexString(long inValue)
        {
            string str = Convert.ToString(inValue, 16).ToUpper();

            if (str.Length % 2 > 0)
                str = "0" + str;

            return str;
        }

        public static string LongToHexString(long[] inValue)
        {
            string str = "";

            foreach (long value in inValue)
                str += LongToHexString(value);

            return str;
        }
    }
}
