﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Be.Windows.Forms;

namespace CH341A_Programmer
{
    public partial class frmGoTo : Form
    {
        private HexBox _MainWindowHexBox = null;

        private bool _NumberAutoChange = false;
        private bool _HexAutoChange = false;
        public frmGoTo(ref HexBox hexBox)
        {
            InitializeComponent();

            _MainWindowHexBox = hexBox;
        }
        public void SetDefaultValue(long byteIndex)
        {
            nud_ByteNumber.Value = byteIndex + 1;
        }

        public void SetMaxByteIndex(long maxByteIndex)
        {
            nud_ByteNumber.Maximum = maxByteIndex + 1;
        }

        public long GetByteIndex()
        {
            return Convert.ToInt64(nud_ByteNumber.Value) - 1;
        }

        private void frmGoTo_Load(object sender, EventArgs e)
        {

        }

        private void frmGoTo_Activated(object sender, EventArgs e)
        {
            nud_ByteNumber.Focus();
            nud_ByteNumber.Select(0, nud_ByteNumber.Value.ToString().Length);
        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            _MainWindowHexBox.SelectionStart = GetByteIndex();
            _MainWindowHexBox.SelectionLength = 1;
            _MainWindowHexBox.Focus();

            this.Close();
            this.Dispose();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void nud_ByteNumber_ValueChanged(object sender, EventArgs e)
        {
            if (!_NumberAutoChange)
            {
                long number = GetByteIndex();

                _HexAutoChange = true;
                tbx_HexLocation.Text = Convert.ToString(number, 16).ToUpper();
                if (tbx_HexLocation.Text.Length % 2 > 0)
                    tbx_HexLocation.Text = "0" + tbx_HexLocation.Text;
                _HexAutoChange = false;
            }
        }

        private void tbx_HexLocation_TextChanged(object sender, EventArgs e)
        {
            if (!_HexAutoChange)
            {
                string hex = tbx_HexLocation.Text;

                _NumberAutoChange = true;
                SetDefaultValue(Convert.ToInt64(hex, 16));
                _NumberAutoChange = false;
            }
        }
    }
}
