﻿namespace CH341A_Programmer
{
    partial class frmMerger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbx_Select = new System.Windows.Forms.GroupBox();
            this.lbl_File1 = new System.Windows.Forms.Label();
            this.lbl_File2 = new System.Windows.Forms.Label();
            this.tbx_File1 = new System.Windows.Forms.TextBox();
            this.tbx_File2 = new System.Windows.Forms.TextBox();
            this.btn_File1 = new System.Windows.Forms.Button();
            this.btn_File2 = new System.Windows.Forms.Button();
            this.gbx_Actions = new System.Windows.Forms.GroupBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Merge = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.gbx_Select.SuspendLayout();
            this.gbx_Actions.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbx_Select
            // 
            this.gbx_Select.Controls.Add(this.btn_File2);
            this.gbx_Select.Controls.Add(this.btn_File1);
            this.gbx_Select.Controls.Add(this.tbx_File2);
            this.gbx_Select.Controls.Add(this.tbx_File1);
            this.gbx_Select.Controls.Add(this.lbl_File2);
            this.gbx_Select.Controls.Add(this.lbl_File1);
            this.gbx_Select.Location = new System.Drawing.Point(12, 12);
            this.gbx_Select.Name = "gbx_Select";
            this.gbx_Select.Size = new System.Drawing.Size(658, 91);
            this.gbx_Select.TabIndex = 0;
            this.gbx_Select.TabStop = false;
            this.gbx_Select.Text = "Select Files";
            // 
            // lbl_File1
            // 
            this.lbl_File1.AutoSize = true;
            this.lbl_File1.Location = new System.Drawing.Point(21, 25);
            this.lbl_File1.Name = "lbl_File1";
            this.lbl_File1.Size = new System.Drawing.Size(35, 13);
            this.lbl_File1.TabIndex = 6;
            this.lbl_File1.Text = "File 1:";
            // 
            // lbl_File2
            // 
            this.lbl_File2.AutoSize = true;
            this.lbl_File2.Location = new System.Drawing.Point(21, 55);
            this.lbl_File2.Name = "lbl_File2";
            this.lbl_File2.Size = new System.Drawing.Size(35, 13);
            this.lbl_File2.TabIndex = 7;
            this.lbl_File2.Text = "File 2:";
            // 
            // tbx_File1
            // 
            this.tbx_File1.Location = new System.Drawing.Point(62, 22);
            this.tbx_File1.Name = "tbx_File1";
            this.tbx_File1.Size = new System.Drawing.Size(552, 20);
            this.tbx_File1.TabIndex = 0;
            // 
            // tbx_File2
            // 
            this.tbx_File2.Location = new System.Drawing.Point(62, 52);
            this.tbx_File2.Name = "tbx_File2";
            this.tbx_File2.Size = new System.Drawing.Size(552, 20);
            this.tbx_File2.TabIndex = 2;
            // 
            // btn_File1
            // 
            this.btn_File1.Location = new System.Drawing.Point(620, 22);
            this.btn_File1.Name = "btn_File1";
            this.btn_File1.Size = new System.Drawing.Size(24, 23);
            this.btn_File1.TabIndex = 1;
            this.btn_File1.Text = "...";
            this.btn_File1.UseVisualStyleBackColor = true;
            this.btn_File1.Click += new System.EventHandler(this.btn_File1_Click);
            // 
            // btn_File2
            // 
            this.btn_File2.Location = new System.Drawing.Point(620, 52);
            this.btn_File2.Name = "btn_File2";
            this.btn_File2.Size = new System.Drawing.Size(24, 23);
            this.btn_File2.TabIndex = 3;
            this.btn_File2.Text = "...";
            this.btn_File2.UseVisualStyleBackColor = true;
            this.btn_File2.Click += new System.EventHandler(this.btn_File2_Click);
            // 
            // gbx_Actions
            // 
            this.gbx_Actions.Controls.Add(this.btn_Cancel);
            this.gbx_Actions.Controls.Add(this.btn_Merge);
            this.gbx_Actions.Location = new System.Drawing.Point(12, 109);
            this.gbx_Actions.Name = "gbx_Actions";
            this.gbx_Actions.Size = new System.Drawing.Size(658, 55);
            this.gbx_Actions.TabIndex = 3;
            this.gbx_Actions.TabStop = false;
            this.gbx_Actions.Text = "Actions";
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.Location = new System.Drawing.Point(569, 19);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 5;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Merge
            // 
            this.btn_Merge.Location = new System.Drawing.Point(476, 19);
            this.btn_Merge.Name = "btn_Merge";
            this.btn_Merge.Size = new System.Drawing.Size(75, 23);
            this.btn_Merge.TabIndex = 4;
            this.btn_Merge.Text = "Merge";
            this.btn_Merge.UseVisualStyleBackColor = true;
            this.btn_Merge.Click += new System.EventHandler(this.btn_Merge_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            this.openFileDialog.Filter = "Binary files (*.bin) | *.bin|All files (*.*) | *.*";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "Binary files (*.bin) | *.bin|All files (*.*) | *.*";
            // 
            // frmMerger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 177);
            this.Controls.Add(this.gbx_Actions);
            this.Controls.Add(this.gbx_Select);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMerger";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "File Merger";
            this.gbx_Select.ResumeLayout(false);
            this.gbx_Select.PerformLayout();
            this.gbx_Actions.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbx_Select;
        private System.Windows.Forms.Button btn_File2;
        private System.Windows.Forms.Button btn_File1;
        private System.Windows.Forms.TextBox tbx_File2;
        private System.Windows.Forms.TextBox tbx_File1;
        private System.Windows.Forms.Label lbl_File2;
        private System.Windows.Forms.Label lbl_File1;
        private System.Windows.Forms.GroupBox gbx_Actions;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Merge;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}