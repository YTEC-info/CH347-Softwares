﻿namespace CH341A_Programmer
{
    partial class frmAutoChip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_ChipId = new System.Windows.Forms.Label();
            this.dgv_Result = new System.Windows.Forms.DataGridView();
            this.tbx_ChipId = new System.Windows.Forms.TextBox();
            this.btn_Select = new System.Windows.Forms.Button();
            this.btn_Cancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Result)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_ChipId
            // 
            this.lbl_ChipId.AutoSize = true;
            this.lbl_ChipId.Location = new System.Drawing.Point(12, 17);
            this.lbl_ChipId.Name = "lbl_ChipId";
            this.lbl_ChipId.Size = new System.Drawing.Size(78, 13);
            this.lbl_ChipId.TabIndex = 0;
            this.lbl_ChipId.Text = "Chip ID Found:";
            // 
            // dgv_Result
            // 
            this.dgv_Result.AllowUserToAddRows = false;
            this.dgv_Result.AllowUserToDeleteRows = false;
            this.dgv_Result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Result.Location = new System.Drawing.Point(15, 52);
            this.dgv_Result.MultiSelect = false;
            this.dgv_Result.Name = "dgv_Result";
            this.dgv_Result.ReadOnly = true;
            this.dgv_Result.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Result.Size = new System.Drawing.Size(392, 214);
            this.dgv_Result.TabIndex = 4;
            this.dgv_Result.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Result_CellContentDoubleClick);
            // 
            // tbx_ChipId
            // 
            this.tbx_ChipId.Location = new System.Drawing.Point(96, 14);
            this.tbx_ChipId.Name = "tbx_ChipId";
            this.tbx_ChipId.Size = new System.Drawing.Size(311, 20);
            this.tbx_ChipId.TabIndex = 5;
            // 
            // btn_Select
            // 
            this.btn_Select.Location = new System.Drawing.Point(241, 280);
            this.btn_Select.Name = "btn_Select";
            this.btn_Select.Size = new System.Drawing.Size(75, 23);
            this.btn_Select.TabIndex = 6;
            this.btn_Select.Text = "Select";
            this.btn_Select.UseVisualStyleBackColor = true;
            this.btn_Select.Click += new System.EventHandler(this.btn_Select_Click);
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.Location = new System.Drawing.Point(332, 280);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 7;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // frmAutoChip
            // 
            this.AcceptButton = this.btn_Select;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_Cancel;
            this.ClientSize = new System.Drawing.Size(422, 315);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_Select);
            this.Controls.Add(this.tbx_ChipId);
            this.Controls.Add(this.dgv_Result);
            this.Controls.Add(this.lbl_ChipId);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAutoChip";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Auto Chip Detect";
            this.Load += new System.EventHandler(this.frmAutoChip_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Result)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_ChipId;
        private System.Windows.Forms.DataGridView dgv_Result;
        private System.Windows.Forms.TextBox tbx_ChipId;
        private System.Windows.Forms.Button btn_Select;
        private System.Windows.Forms.Button btn_Cancel;
    }
}