﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace CH341A_Programmer
{
    public partial class frmMerger : Form
    {
        public frmMerger()
        {
            InitializeComponent();
        }

        private void btn_File1_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                tbx_File1.Text = openFileDialog.FileName;
            }
        }

        private void btn_File2_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                tbx_File2.Text = openFileDialog.FileName;
            }
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Merge_Click(object sender, EventArgs e)
        {
            if (!File.Exists(tbx_File1.Text))
            {
                MessageBox.Show("File 1 does not exist.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!File.Exists(tbx_File2.Text))
            {
                MessageBox.Show("File 2 does not exist.", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string saveFile = saveFileDialog.FileName;

                try
                {
                    byte[] buffer = new byte[8192];

                    FileStream inStream = new FileStream(tbx_File1.Text, FileMode.Open);
                    FileStream outStream = new FileStream(saveFile, FileMode.Create);

                    int bytesRead = inStream.Read(buffer, 0, 8192);
                    while (bytesRead > 0)
                    {
                        outStream.Write(buffer, 0, bytesRead);
                        bytesRead = inStream.Read(buffer, 0, 8192);
                    }

                    inStream.Close();
                    inStream.Dispose();

                    inStream = new FileStream(tbx_File2.Text, FileMode.Open);

                    bytesRead = inStream.Read(buffer, 0, 8192);
                    while (bytesRead > 0)
                    {
                        outStream.Write(buffer, 0, bytesRead);
                        bytesRead = inStream.Read(buffer, 0, 8192);
                    }

                    inStream.Close();
                    inStream.Dispose();

                    outStream.Close();
                    outStream.Dispose();

                    MessageBox.Show("Two files have been merged successfully at (" + saveFile + ").", Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, Program.SoftwareName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
