﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;

namespace CH341A_Programmer
{
    public class ChipSettings
    {
        private string _Path = Path.Combine(Directory.GetCurrentDirectory(), "chiplist.xml");
        private XmlDocument _Doc = null;
        private List<Chip> _ChipList = null;

        public ChipSettings()
        {
            _ChipList = new List<Chip>();
        }

        public ChipSettings(string path)
        {
            _Path = path;
            _ChipList = new List<Chip>();
        }

        public string LoadChipList()
        {
            string errMsg = "";
            Chip chip = null;

            try
            {
                _Doc = new XmlDocument();
                _Doc.Load(_Path);

                XmlElement root = _Doc.DocumentElement;

                foreach (XmlNode typeNode in root.ChildNodes)
                {
                    string chipType = typeNode.Name;

                    foreach (XmlNode manufacturerNode in typeNode.ChildNodes)
                    {
                        string manufacturer = manufacturerNode.Name;

                        foreach (XmlNode chipNode in manufacturerNode.ChildNodes)
                        {
                            switch (chipType)
                            {
                                case "SPI":
                                    chip = GetSPIChipFromXml(manufacturer, chipNode);
                                    break;
                                case "I2C":
                                    chip = GetI2CChipFromXml(manufacturer, chipNode);
                                    break;
                                case "MW":
                                    chip = GetMWChipFromXml(manufacturer, chipNode);
                                    break;
                            }

                            _ChipList.Add(chip);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
            }

            return errMsg;
        }

        public string[] GetManufacturers(string typeName)
        {
            List<Chip> matchedChips = _ChipList.FindAll(c => c.GetType().Name == typeName).OrderBy(c => c.Manufacturer).ToList();

            List<string> manufacturerList = new List<string>();
            string lastManufacturer = "";

            foreach (Chip chip in matchedChips)
            {
                if (chip.Manufacturer != lastManufacturer)
                {
                    manufacturerList.Add(chip.Manufacturer);
                    lastManufacturer = chip.Manufacturer;
                }
            }

            return manufacturerList.ToArray();
        }

        public List<Chip> GetChipList(string typeName, string manufacturer)
        {
            return _ChipList.FindAll(c => c.GetType().Name == typeName).FindAll(c => c.Manufacturer == manufacturer).OrderBy(c => c.Name).ToList();
        }

        public List<ChipSelectionGridItem> GetGridItemsByKeywords(string text)
        {
            List<ChipSelectionGridItem> result = new List<ChipSelectionGridItem>();

            List<Chip> chips = _ChipList;

            if (text != "")
            {
                chips = _ChipList.FindAll(c => c.Name.ToLower().Contains(text.ToLower()));
            }

            chips = chips.OrderBy(c => c.GetType().Name).ThenBy(c => c.Manufacturer).ThenBy(c => c.Name).ToList();

            foreach (Chip chip in chips)
            {
                ChipSelectionGridItem newItem = new ChipSelectionGridItem(chip.GetType().Name, chip.Manufacturer, chip.Name);
                result.Add(newItem);
            }

            return result;
        }

        public List<ChipSelectionGridItem> GetGridItemsById(string id)
        {
            List<ChipSelectionGridItem> result = new List<ChipSelectionGridItem>();

            List<Chip> chips = _ChipList;

            if (id != "")
            {
                chips = _ChipList.FindAll(c => c.GetType().Name == "SPI_Chip").FindAll(c => ((SPI_Chip)c).Id == id);
            }

            chips = chips.OrderBy(c => c.GetType().Name).ThenBy(c => c.Manufacturer).ThenBy(c => c.Name).ToList();

            foreach (Chip chip in chips)
            {
                ChipSelectionGridItem newItem = new ChipSelectionGridItem(chip.GetType().Name, chip.Manufacturer, chip.Name);
                result.Add(newItem);
            }

            return result;
        }

        public Chip GetChip(string type, string manufacturer, string name)
        {
            return _ChipList.Find(c => (c.GetType().Name == type) && (c.Manufacturer == manufacturer) && (c.Name == name));
        }

        private SPI_Chip GetSPIChipFromXml(string manufacturer, XmlNode chipNode)
        {
            SPI_Chip chip = null;

            XmlElement element = (XmlElement)chipNode;

            string name = element.Name;
            long size = long.Parse(element.GetAttribute("size"));
            string pageSize = element.GetAttribute("page");

            string id = "";
            if (element.HasAttribute("id"))
                id = element.GetAttribute("id");

            string cmd = "25";
            if (element.HasAttribute("spicmd"))
                cmd = element.GetAttribute("spicmd");

            int otp = 0;
            if (element.HasAttribute("otp"))
                otp = int.Parse(element.GetAttribute("otp"));

            chip = new SPI_Chip(manufacturer, name, size, id, pageSize, cmd, otp);

            return chip;
        }

        private I2C_Chip GetI2CChipFromXml(string manufacturer, XmlNode chipNode)
        {
            I2C_Chip chip = null;

            XmlElement element = (XmlElement)chipNode;

            string name = element.Name;
            long size = long.Parse(element.GetAttribute("size"));
            string pageSize = element.GetAttribute("page");
            int addressType = int.Parse(element.GetAttribute("addrtype"));

            chip = new I2C_Chip(manufacturer, name, size, pageSize, addressType);

            return chip;
        }

        private MW_Chip GetMWChipFromXml(string manufacturer, XmlNode chipNode)
        {
            MW_Chip chip = null;

            XmlElement element = (XmlElement)chipNode;

            string name = element.Name;
            long size = long.Parse(element.GetAttribute("size"));
            int addressBitLength = int.Parse(element.GetAttribute("addrbitlen"));

            chip = new MW_Chip(manufacturer, name, size, addressBitLength);

            return chip;
        }
    }
}
