﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH341A_Programmer
{
    public class SPI_Chip : Chip
    {
        private string _Id = "";
        private string _PageSize = "";
        private string _SpiCommand = "";
        private int _OTP = 0;

        public SPI_Chip(string manufacturer, string name, long size, string id, string pageSize, string spiCommand, int otp) : base(manufacturer, name, size)
        {
            _Id = id;
            _PageSize = pageSize;
            _SpiCommand = spiCommand;
            _OTP = otp;
        }

        public string Id
        {
            get { return _Id; }
            set { _Id = value; }
        }

        public string PageSize
        {
            get { return _PageSize; }
            set { _PageSize = value; }
        }

        public string SpiCommand
        {
            get { return _SpiCommand; }
            set { _SpiCommand = value; }
        }

        public int OTP
        {
            get { return _OTP; }
            set { _OTP = value; }
        }
    }
}
