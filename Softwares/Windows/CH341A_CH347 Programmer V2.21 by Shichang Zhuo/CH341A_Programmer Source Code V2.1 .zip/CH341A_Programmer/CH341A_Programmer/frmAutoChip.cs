﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CH341A_Programmer
{
    public partial class frmAutoChip : Form
    {
        private ChipSettings _ChipSettings = null;

        private frmMain _MainFrom = null;

        private string[] _ChipId = null;

        public frmAutoChip(ChipSettings chipSettings, frmMain frm, string[] id)
        {
            InitializeComponent();

            _ChipSettings = chipSettings;
            _MainFrom = frm;
            _ChipId = id;
        }

        private void SelectChip()
        {
            if (dgv_Result.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgv_Result.SelectedRows[0];

                string chipType = row.Cells[0].Value.ToString();
                string chipManufacturer = row.Cells[1].Value.ToString();
                string chipName = row.Cells[2].Value.ToString();

                Chip chip = _ChipSettings.GetChip(chipType, chipManufacturer, chipName);

                _MainFrom.SetChip(chip);

                this.Close();
                this.Dispose();
            }
        }

        private void SearchChips(string id)
        {
            dgv_Result.DataSource = null;

            dgv_Result.DataSource = _ChipSettings.GetGridItemsById(id);

            for (int i = 0; i < dgv_Result.ColumnCount; ++i)
            {
                dgv_Result.Columns[i].AutoSizeMode = i < dgv_Result.ColumnCount - 1 ? DataGridViewAutoSizeColumnMode.AllCells : DataGridViewAutoSizeColumnMode.Fill;
            }

            dgv_Result.Refresh();
        }

        private void frmAutoChip_Load(object sender, EventArgs e)
        {
            tbx_ChipId.Text = _ChipId[0];
            SearchChips(_ChipId[0]);
        }

        private void btn_Select_Click(object sender, EventArgs e)
        {
            SelectChip();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void dgv_Result_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            SelectChip();
        }
    }
}
