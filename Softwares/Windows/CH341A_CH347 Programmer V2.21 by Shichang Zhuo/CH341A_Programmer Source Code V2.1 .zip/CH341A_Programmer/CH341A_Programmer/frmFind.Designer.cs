﻿namespace CH341A_Programmer
{
    partial class frmFind
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbx_Find = new System.Windows.Forms.GroupBox();
            this.chk_MatchCases = new System.Windows.Forms.CheckBox();
            this.tbx_Text = new System.Windows.Forms.TextBox();
            this.rbn_Hex = new System.Windows.Forms.RadioButton();
            this.rbn_Text = new System.Windows.Forms.RadioButton();
            this.gbx_Actions = new System.Windows.Forms.GroupBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.gbx_Find.SuspendLayout();
            this.gbx_Actions.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbx_Find
            // 
            this.gbx_Find.Controls.Add(this.chk_MatchCases);
            this.gbx_Find.Controls.Add(this.tbx_Text);
            this.gbx_Find.Controls.Add(this.rbn_Hex);
            this.gbx_Find.Controls.Add(this.rbn_Text);
            this.gbx_Find.Location = new System.Drawing.Point(12, 12);
            this.gbx_Find.Name = "gbx_Find";
            this.gbx_Find.Size = new System.Drawing.Size(293, 149);
            this.gbx_Find.TabIndex = 0;
            this.gbx_Find.TabStop = false;
            this.gbx_Find.Text = "Find What";
            // 
            // chk_MatchCases
            // 
            this.chk_MatchCases.AutoSize = true;
            this.chk_MatchCases.Location = new System.Drawing.Point(58, 20);
            this.chk_MatchCases.Name = "chk_MatchCases";
            this.chk_MatchCases.Size = new System.Drawing.Size(88, 17);
            this.chk_MatchCases.TabIndex = 5;
            this.chk_MatchCases.Text = "Match Cases";
            this.chk_MatchCases.UseVisualStyleBackColor = true;
            // 
            // tbx_Text
            // 
            this.tbx_Text.Location = new System.Drawing.Point(6, 43);
            this.tbx_Text.Multiline = true;
            this.tbx_Text.Name = "tbx_Text";
            this.tbx_Text.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbx_Text.Size = new System.Drawing.Size(279, 93);
            this.tbx_Text.TabIndex = 0;
            // 
            // rbn_Hex
            // 
            this.rbn_Hex.AutoSize = true;
            this.rbn_Hex.Location = new System.Drawing.Point(241, 19);
            this.rbn_Hex.Name = "rbn_Hex";
            this.rbn_Hex.Size = new System.Drawing.Size(44, 17);
            this.rbn_Hex.TabIndex = 4;
            this.rbn_Hex.Text = "Hex";
            this.rbn_Hex.UseVisualStyleBackColor = true;
            this.rbn_Hex.CheckedChanged += new System.EventHandler(this.rbn_Hex_CheckedChanged);
            // 
            // rbn_Text
            // 
            this.rbn_Text.AutoSize = true;
            this.rbn_Text.Checked = true;
            this.rbn_Text.Location = new System.Drawing.Point(6, 19);
            this.rbn_Text.Name = "rbn_Text";
            this.rbn_Text.Size = new System.Drawing.Size(46, 17);
            this.rbn_Text.TabIndex = 3;
            this.rbn_Text.TabStop = true;
            this.rbn_Text.Text = "Text";
            this.rbn_Text.UseVisualStyleBackColor = true;
            // 
            // gbx_Actions
            // 
            this.gbx_Actions.Controls.Add(this.btn_Cancel);
            this.gbx_Actions.Controls.Add(this.btn_Find);
            this.gbx_Actions.Location = new System.Drawing.Point(12, 167);
            this.gbx_Actions.Name = "gbx_Actions";
            this.gbx_Actions.Size = new System.Drawing.Size(293, 55);
            this.gbx_Actions.TabIndex = 1;
            this.gbx_Actions.TabStop = false;
            this.gbx_Actions.Text = "Actions";
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.Location = new System.Drawing.Point(210, 19);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 2;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(129, 19);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 23);
            this.btn_Find.TabIndex = 1;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // frmFind
            // 
            this.AcceptButton = this.btn_Find;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_Cancel;
            this.ClientSize = new System.Drawing.Size(312, 231);
            this.Controls.Add(this.gbx_Actions);
            this.Controls.Add(this.gbx_Find);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmFind";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Find";
            this.Load += new System.EventHandler(this.frmFind_Load);
            this.gbx_Find.ResumeLayout(false);
            this.gbx_Find.PerformLayout();
            this.gbx_Actions.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbx_Find;
        private System.Windows.Forms.TextBox tbx_Text;
        private System.Windows.Forms.RadioButton rbn_Hex;
        private System.Windows.Forms.RadioButton rbn_Text;
        private System.Windows.Forms.CheckBox chk_MatchCases;
        private System.Windows.Forms.GroupBox gbx_Actions;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Find;
    }
}